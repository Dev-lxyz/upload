module.exports = function (app) {
  const axios = require("axios");

  const formatAudio = [
    "mp3",
    "m4a",
    "webm",
    "acc",
    "flac",
    "opus",
    "ogg",
    "wav",
    "4k"
  ];

  const formatVideo = [
    "360",
    "480",
    "720",
    "1080",
    "1440"
  ];

  const instance = axios.create({
    timeout: 10000,
    headers: {
      "User-Agent": "Mozilla/5.0",
      "Accept-Language": "es-PE,es;q=0.9"
    }
  });

  const ddownr = {
    download: async (url, format) => {
      try {
        const response = await axios.get(
          `https://p.oceansaver.in/ajax/download.php?copyright=0&format=${format}&url=${encodeURIComponent(url)}`,
          {
            headers: {
              "User-Agent": "MyApp/1.0",
              "Referer": "https://ddownr.com/enW7/youtube-video-downloader"
            }
          }
        );

        const data = response.data;

        const media = await ddownr.cekProgress(data.id);

        return {
          success: true,
          format,
          title: data.title,
          thumbnail: data.info.image,
          downloadUrl: media
        };

      } catch (error) {
        return {
          success: false,
          message: error.message
        };
      }
    },

    cekProgress: async (id) => {
      try {
        const progressResponse = await axios.get(
          `https://p.oceansaver.in/ajax/progress.php?id=${id}`,
          {
            headers: {
              "User-Agent": "MyApp/1.0",
              "Referer": "https://ddownr.com/enW7/youtube-video-downloader"
            }
          }
        );

        const data = progressResponse.data;

        if (data.progress === 1000) {
          return data.download_url;
        }

        await new Promise(resolve => setTimeout(resolve, 1000));

        return ddownr.cekProgress(id);

      } catch (error) {
        return {
          success: false,
          message: error.message
        };
      }
    }
  };

  async function ytSearch(query) {
    const { data } = await instance.get(
      "https://www.youtube.com/results",
      {
        params: {
          search_query: query
        }
      }
    );

    const match = data.match(
      /var ytInitialData = (.*?);<\/script>/
    );

    if (!match) {
      throw new Error("No se pudo obtener data");
    }

    const json = JSON.parse(match[1]);

    const contents =
      json.contents
        ?.twoColumnSearchResultsRenderer
        ?.primaryContents
        ?.sectionListRenderer
        ?.contents?.[0]
        ?.itemSectionRenderer
        ?.contents || [];

    const first = contents.find(v => v.videoRenderer);

    if (!first) {
      throw new Error("No se encontraron resultados");
    }

    const r = first.videoRenderer;

    let views = r.viewCountText?.simpleText || "";

    views = views.replace(/ views?/i, "").trim();

    return {
      title: r.title?.runs?.[0]?.text || "",
      videoId: r.videoId,
      author: r.ownerText?.runs?.[0]?.text || "",
      url: "https://youtu.be/" + r.videoId,
      duration: r.lengthText?.simpleText || "0:00",
      views,
      uploaded: r.publishedTimeText?.simpleText || "",
      thumbnail:
        r.thumbnail?.thumbnails?.slice(-1)[0]?.url || ""
    };
  }

  app.get("/api/play/youtube", async (req, res) => {
    try {
      const { q, format } = req.query;

      if (!q) {
        return res.status(400).json({
          status: false,
          message: "Falta el parámetro ?q="
        });
      }

      const quality = format || "mp3";

      const searchResult = await ytSearch(q);

      const dl = await ddownr.download(
        searchResult.url,
        quality
      );

      if (!dl.success) {
        throw new Error(dl.message);
      }

      res.json({
        status: true,
        result: {
          query: q,
          title: dl.title || searchResult.title,
          author: searchResult.author,
          duration: searchResult.duration,
          views: searchResult.views,
          uploaded: searchResult.uploaded,
          videoId: searchResult.videoId,
          url: searchResult.url,
          format: quality,
          thumbnail:
            dl.thumbnail || searchResult.thumbnail,
          download: dl.downloadUrl,
          formats: {
            audio: formatAudio,
            video: formatVideo
          }
        }
      });

    } catch (e) {
      res.status(500).json({
        status: false,
        message: e.message
      });
    }
  });
};