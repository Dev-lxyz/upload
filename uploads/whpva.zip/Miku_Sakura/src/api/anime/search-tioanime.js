const axios = require("axios")
const cheerio = require("cheerio")

module.exports = function(app) {
  async function searchAnime(query) {
    const { data } = await axios.post(
      "https://tioanime.com/directorio",
      new URLSearchParams({
        q: query
      }),
      {
        headers: {
          "user-agent":
            "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/147.0.0.0 Mobile Safari/537.36",
          "referer": "https://tioanime.com/",
          "origin": "https://tioanime.com",
          "content-type":
            "application/x-www-form-urlencoded"
        },
        timeout: 30000
      }
    )

    const $ = cheerio.load(data)

    const result = []

    $("article").each((_, el) => {

      const a = $(el).find("a").first()

      let link = a.attr("href") || ""

      if (link && !link.startsWith("http")) {
        link = "https://tioanime.com" + link
      }

      let image =
        $(el).find("img").attr("src") ||
        $(el).find("img").attr("data-src") ||
        ""

      if (image.startsWith("//")) {
        image = "https:" + image
      }

      const title =
        $(el).find("h3").text().trim() ||
        a.attr("title") ||
        ""

      const type =
        $(el).find(".badge").text().trim() || ""

      if (title && link) {
        result.push({
          title,
          type,
          link,
          image
        })
      }

    })

    return result
  }

  app.get("/anime/search/tioanime", async (req, res) => {
    try {
      const { q } = req.query
      if (!q) {
        return res.status(400).json({
          status: false,
          message: "Falta el parámetro q"
        })
      }

      const result = await searchAnime(q)

      return res.json({
        status: true,
        total: result.length,
        result
      })

    } catch (e) {

      return res.status(500).json({
        status: false,
        message: e.message
      })

    }
  })

}