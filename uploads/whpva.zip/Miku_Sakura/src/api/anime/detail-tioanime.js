const axios = require("axios")
const cheerio = require("cheerio")

module.exports = function(app) {

  async function animeDetail(url) {

    const { data } = await axios.get(url, {
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/147.0.0.0 Mobile Safari/537.36",
        "referer": "https://tioanime.com/",
        "origin": "https://tioanime.com"
      },
      timeout: 30000
    })

    const $ = cheerio.load(data)

    const title =
      $(".anime-title").text().trim() ||
      $("h1").first().text().trim()

    const description =
      $(".anime-description").text().trim() ||
      $('meta[name="description"]').attr("content") ||
      ""

    let image =
      $(".anime-cover img").attr("src") ||
      $("img").first().attr("src") ||
      ""

    if (image.startsWith("//")) {
      image = "https:" + image
    }

    const info = {}

    $(".anime-info p").each((_, el) => {

      const txt = $(el).text().trim()

      const split = txt.split(":")

      if (split.length >= 2) {
        const key = split.shift().trim().toLowerCase()
        const value = split.join(":").trim()

        info[key] = value
      }

    })

    const episodes = []

    $(".episodes li, .episode-list li").each((_, el) => {

      const a = $(el).find("a")

      let epLink = a.attr("href") || ""

      if (epLink && !epLink.startsWith("http")) {
        epLink = "https://tioanime.com" + epLink
      }

      const epTitle =
        a.text().trim() ||
        $(el).text().trim()

      if (epTitle && epLink) {
        episodes.push({
          title: epTitle,
          link: epLink
        })
      }

    })

    return {
      title,
      description,
      image,
      info,
      totalEpisodes: episodes.length,
      episodes
    }
  }

  app.get("/anime/detail/tioanime", async (req, res) => {
    try {

      const { url } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          message: "Falta el parámetro url"
        })
      }

      const result = await animeDetail(url)

      return res.json({
        status: true,
        result
      })

    } catch (e) {

      return res.status(500).json({
        status: false,
        message: e.message
      })

    }
  })

}