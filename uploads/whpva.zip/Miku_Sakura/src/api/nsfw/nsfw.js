const axios = require("axios");

module.exports = function (app) {
  const SFW_TYPES = ["waifu", "neko", "trap", "blowjob"];

  app.get("/nsfw/types", (req, res) => {
    res.json({
      status: true,
      result: { types: SFW_TYPES }
    });
  });

  app.get("/nsfw/nsfw", async (req, res) => {
    try {
      const type = SFW_TYPES[Math.floor(Math.random() * SFW_TYPES.length)];

      const { data } = await axios.get(`https://api.waifu.pics/nsfw/${type}`);

      const extension = data.url.split(".").pop().split("?")[0];
      const filename = `${type}_${Date.now()}.${extension}`;

      res.json({
        status: true,
        result: {
          type,
          name: filename,
          dl_url: data.url
        }
      });
    } catch (err) {
      res.status(500).json({
        status: false,
        result: { error: err.message }
      });
    }
  });
};