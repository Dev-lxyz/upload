const fs = require('fs');
const path = require('path');

module.exports = function(app) {

  app.get('/api/top-endpoints', async (req, res) => {
    try {
      const dbPath = path.join(__dirname, '../../database.json');

      if (!fs.existsSync(dbPath)) {
        return res.status(500).json({
          status: false,
          error: "No existe database.json"
        });
      }

      const raw = fs.readFileSync(dbPath);
      const json = JSON.parse(raw);

      const endpoints = json.endpoints || {};
      const clean = {};

      const ignore = ['/docs', '/status-page', '/status', '/src/preview.png', '/favicon.ico'];
      const limit = parseInt(req.query.limit) || 10;

      for (const key in endpoints) {
        const base = key.split('?')[0];

        if (ignore.includes(base)) continue;

        const data = endpoints[key];

        if (!clean[base]) {
          clean[base] = {
            count: 0,
            errors: 0,
            ms_total: 0,
            hits: 0,
            status: 200
          };
        }

        clean[base].count += data.count || 0;
        clean[base].errors += data.errors || 0;
        clean[base].ms_total += data.ms || 0;
        clean[base].hits++;
        if (data.status >= 400) {
          clean[base].status = 500;
        }
      }

      const arr = Object.entries(clean).map(([endpoint, data]) => ({
        router: endpoint,
        count: data.count,
        errors: data.errors,
        ms: Math.floor(data.ms_total / data.hits),
        status: data.status
      }));

      const top = arr
        .sort((a, b) => b.count - a.count)
        .slice(0, limit);

      res.json({
        status: true,
        total: arr.length,
        limit,
        top
      });

    } catch (err) {
      res.status(500).json({
        status: false,
        error: "Error leyendo stats",
        detail: err.message
      });
    }
  });

};