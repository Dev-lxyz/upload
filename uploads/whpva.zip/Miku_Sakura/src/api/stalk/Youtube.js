const fetch = require('node-fetch')
const cheerio = require('cheerio')

module.exports = function (app) {

  async function getYouTubeProfile(username) {
    const user = username.startsWith('@') ? username : '@' + username

    const res = await fetch(`https://m.youtube.com/${user}`, {
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })

    const html = await res.text()
    const $ = cheerio.load(html)

    const name = $('meta[property="og:title"]').attr('content') || ''
    const description = $('meta[property="og:description"]').attr('content') || ''
    const image = $('meta[property="og:image"]').attr('content') || ''
    const url = $('link[rel="canonical"]').attr('href') || ''

    const bannerMatch = html.match(/https:\/\/yt3\.googleusercontent\.com\/[^\s"']+?=w\d+-fcrop64=[^"']+/i)
    const banner = bannerMatch ? bannerMatch[0] : ''

    let subscribers = null
    const subsMatch = html.match(/(\d[\d.,]*)\s+subscribers/i)
    if (subsMatch) subscribers = subsMatch[1]

    // fallback
    if (!subscribers) {
      const altRes = await fetch(`https://www.youtube.com/${user}`, {
        headers: { 'User-Agent': 'Mozilla/5.0' }
      })
      const altHtml = await altRes.text()
      const altMatch = altHtml.match(/"content"\s*:\s*"(\d[\d.,]*[MK]?)\s*subscribers"/)
      subscribers = altMatch ? altMatch[1] : null
    }

    // videos
    const videoMatches = [...html.matchAll(/\/watch\?v=([a-zA-Z0-9_-]{11})/g)]
    const videoSet = new Set()
    const videos = []

    for (const match of videoMatches) {
      const id = match[1]
      if (!videoSet.has(id)) {
        videoSet.add(id)
        videos.push(`https://www.youtube.com/watch?v=${id}`)
        if (videos.length === 5) break
      }
    }

    const idMatch = url.match(/\/channel\/(UC[\w-]+)/)
    const channelId = idMatch ? idMatch[1] : null

    return {
      name,
      username: user,
      description,
      image,
      banner,
      subscribers,
      url,
      channelId,
      videos
    }
  }

  app.get('/stalk/youtube', async (req, res) => {
    try {
      const { username } = req.query

      if (!username) {
        return res.status(400).json({
          status: false,
          message: "Falta parámetro 'username'"
        })
      }

      const data = await getYouTubeProfile(username)

      if (!data.name || data.name === 'YouTube') {
        return res.status(404).json({
          status: false,
          message: "Perfil no encontrado"
        })
      }

      res.json({
        status: true,
        result: data
      })

    } catch (e) {
      res.status(500).json({
        status: false,
        message: "Error al obtener datos",
        error: e.message
      })
    }
  })

}