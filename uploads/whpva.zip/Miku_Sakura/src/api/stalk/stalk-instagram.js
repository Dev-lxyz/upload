const axios = require("axios");
const cheerio = require("cheerio");

module.exports = function (app) {

  async function stalkIg(username) {
    const url = `https://socialstats.info/report/${username}/instagram`;

    const { data } = await axios.get(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
        "Accept": "text/html,application/xhtml+xml",
        "Referer": "https://socialstats.info/"
      },
      timeout: 20000
    });

    const $ = cheerio.load(data);

    const title = $("title").text() || "";

    if (!title.toLowerCase().includes(username.toLowerCase())) {
      return { error: "User not found" };
    }

    const name =
      $("h1").first().text().trim() ||
      $(".profile-name").first().text().trim() ||
      null;

    const profileUrl =
      $('a[href*="instagram.com"]').first().attr("href") || null;

    const avatar =
      $(".instagram-avatar").attr("src") ||
      $("img.avatar").attr("src") ||
      null;

    // fallback numbers robusto
    const numbers = $(".report-header-number")
      .toArray()
      .map(e => $(e).text().trim());

    const followers = numbers[0] || null;
    const uploads = numbers[1] || null;
    const engagement = numbers[2] || null;

    return {
      username,
      name,
      profileUrl,
      avatar,
      followers,
      uploads,
      engagement
    };
  }

  // 🚀 ENDPOINT
  app.get("/stalk/instagram", async (req, res) => {
    try {
      const { user } = req.query;

      if (!user) {
        return res.json({
          status: false,
          error: "Missing ?user="
        });
      }

      const data = await stalkIg(user);

      if (data.error) {
        return res.json({
          status: false,
          error: data.error
        });
      }

      res.json({
        status: true,
        result: data
      });

    } catch (e) {
      res.json({
        status: false,
        error: e.message
      });
    }
  });

};