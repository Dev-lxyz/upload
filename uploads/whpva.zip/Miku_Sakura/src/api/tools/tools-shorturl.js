module.exports = function (app) {
  const crypto = require('crypto')
  const fetch = require('node-fetch')

  const owner = 'Dev-lxyz'
  const repo = 'upload'
  const filePath = 'upload/links.json'
  const token = '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'

  let urlMap = {}
  let shaCache = null
  let saveTimeout = null

  async function loadLinks() {
    try {
      const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`, {
        headers: { Authorization: `token ${token}` }
      })

      const data = await res.json()

      shaCache = data.sha
      const content = Buffer.from(data.content, 'base64').toString()
      urlMap = JSON.parse(content)

    } catch (e) {
      console.error('Load error:', e.message)
      urlMap = {}
    }
  }

  function saveLinks() {
    if (saveTimeout) return

    saveTimeout = setTimeout(async () => {
      try {
        const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`, {
          method: 'PUT',
          headers: {
            Authorization: `token ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            message: 'update links.json',
            content: Buffer.from(JSON.stringify(urlMap, null, 2)).toString('base64'),
            sha: shaCache
          })
        })

        const data = await res.json()
        if (data.content?.sha) shaCache = data.content.sha

      } catch (e) {
        console.error('Save error:', e.message)
      }

      saveTimeout = null
    }, 5000) // ⏱ guarda cada 5s (no spam)
  }

  loadLinks()

  app.get('/tools/shortlink.php', async (req, res) => {
    try {
      let { url, id } = req.query

      if (!url || !/^https?:\/\//.test(url)) {
        return res.status(400).json({
          status: false,
          error: 'URL inválida'
        })
      }

      if (id) {
        id = id.toLowerCase().replace(/[^a-z0-9_-]/g, '')
        if (urlMap[id]) {
          return res.status(409).json({
            status: false,
            error: 'Ese ID ya existe'
          })
        }
      }

      const hash = id || crypto.createHash('md5').update(url).digest('hex').slice(0, 6)

      urlMap[hash] = url

      saveLinks()

      const domain = req.headers.host

      res.json({
        status: true,
        data: {
          id: hash,
          short: `https://${domain}/s/${hash}`,
          original_url: url
        }
      })

    } catch (e) {
      res.status(500).json({
        status: false,
        error: e.message
      })
    }
  })

  app.get('/s/:id', (req, res) => {
    const { id } = req.params

    if (!/^[a-z0-9_-]{3,20}$/.test(id)) {
      return res.status(404).json({
        status: false,
        error: 'ID inválido'
      })
    }

    const target = urlMap[id]

    if (!target) {
      return res.status(404).json({
        status: false,
        error: 'URL no encontrada'
      })
    }

    res.redirect(301, target)
  })
}