const express = require('express')
const fetch = require('node-fetch')
const FormData = require('form-data')
const fs = require('fs')
const path = require('path')
const crypto = require('crypto')

const ALLOWED_SCALES = ["2", "4", "8", "16"]

module.exports = function(app) {

  app.get('/tools/hd', async (req, res) => {

    try {

      const { url, scale = "2" } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          error: "Falta url"
        })
      }

      if (!ALLOWED_SCALES.includes(String(scale))) {
        return res.status(400).json({
          status: false,
          error: `Scale inválido (${ALLOWED_SCALES.join(', ')})`
        })
      }

      const imgResp = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0'
        }
      })

      if (!imgResp.ok) {
        throw new Error(
          `No se pudo descargar (${imgResp.status})`
        )
      }

      const mimeType =
        imgResp.headers.get('content-type') ||
        'image/png'

      const imgBuffer =
        await imgResp.buffer()

      const ext =
        mimeType.split('/')[1] || 'png'

      const form = new FormData()

      form.append(
        'image',
        imgBuffer,
        {
          filename: `image.${ext}`,
          contentType: mimeType
        }
      )

      form.append(
        'scale',
        String(scale)
      )

      const pixelcutRes = await fetch(
        'https://api2.pixelcut.app/image/upscale/v1',
        {
          method: 'POST',
          headers: {
            ...form.getHeaders(),
            accept: 'application/json',
            'x-client-version': 'web',
            'x-locale': 'en',
            origin: 'https://pixelcut.ai',
            referer: 'https://pixelcut.ai/'
          },
          body: form
        }
      )

      const json =
        await pixelcutRes.json()

      if (
        !json ||
        !json.result_url
      ) {
        throw new Error(
          'Pixelcut no devolvió imagen'
        )
      }

      const hdResp =
        await fetch(json.result_url)

      const hdBuffer =
        await hdResp.buffer()

      if (!fs.existsSync('./files')) {
        fs.mkdirSync('./files')
      }

      const name =
        crypto.randomBytes(16)
          .toString('hex') + '.png'

      const filePath =
        path.join(
          process.cwd(),
          'files',
          name
        )

      fs.writeFileSync(
        filePath,
        hdBuffer
      )

      res.json({
        status: true,
        data: {
          scale: `${scale}x`,
          original_url: url,
          upscaled_url:
            `${req.protocol}://${req.get('host')}/files/${name}`
        }
      })

    } catch (err) {

      console.error(
        '[HD-ENDPOINT]',
        err.message
      )

      res.status(500).json({
        status: false,
        error: err.message
      })

    }

  })

}