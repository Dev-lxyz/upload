module.exports = function (app) {

  const { CookieJar } = require('tough-cookie')
  const { v4: uuidv4 } = require('uuid')

  // ─── User Agents rotativos ────────────────────────────────────────────────
  const USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0'
  ]

  const randomUA = () => USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)]

  function buildHeaders (ua) {
    return {
      'User-Agent': ua,
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Cache-Control': 'max-age=0',
      'Sec-Ch-Ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
      'Sec-Ch-Ua-Mobile': '?0',
      'Sec-Ch-Ua-Platform': '"Windows"',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'none',
      'Sec-Fetch-User': '?1',
      'Upgrade-Insecure-Requests': '1',
      'DNT': '1',
      'Connection': 'keep-alive'
    }
  }

  // ─── Método 1: DuckDuckGo (más confiable, sin bloqueos) ──────────────────
  async function searchDDG (query, limit = 20) {
    const ua = randomUA()
    const headers = buildHeaders(ua)

    const initUrl = `https://duckduckgo.com/?q=${encodeURIComponent(query)}&iax=images&ia=images`
    const initRes = await fetch(initUrl, {
      headers,
      signal: AbortSignal.timeout(12000)
    })
    const initHtml = await initRes.text()

    const vqdMatch = initHtml.match(/vqd=(['"])([^'"]+)\1/) || initHtml.match(/vqd=([\d-]+)/)
    const vqd = vqdMatch ? (vqdMatch[2] || vqdMatch[1]) : null
    if (!vqd) throw new Error('No se pudo obtener token vqd de DuckDuckGo')

    await new Promise(r => setTimeout(r, 800 + Math.random() * 600))

    const imgUrl = new URL('https://duckduckgo.com/i.js')
    imgUrl.searchParams.set('l', 'es-es')
    imgUrl.searchParams.set('o', 'json')
    imgUrl.searchParams.set('q', query)
    imgUrl.searchParams.set('vqd', vqd)
    imgUrl.searchParams.set('f', ',,,,,')
    imgUrl.searchParams.set('p', '1')

    headers['Referer'] = initUrl

    const imgRes = await fetch(imgUrl.toString(), {
      headers,
      signal: AbortSignal.timeout(12000)
    })
    if (!imgRes.ok) throw new Error(`DDG API error: ${imgRes.status}`)

    const data = await imgRes.json()
    return (data.results || []).slice(0, limit).map(item => ({
      title: item.title || query,
      image: item.image || '',
      thumbnail: item.thumbnail || item.image || '',
      source: item.url || '',
      width: item.width || null,
      height: item.height || null
    })).filter(r => r.image)
  }

  // ─── Método 2: Scraping directo de Google Images ──────────────────────────
  async function searchGoogle (query, limit = 20) {
    const ua = randomUA()
    const headers = buildHeaders(ua)

    // Obtener cookies iniciales
    try {
      const initRes = await fetch('https://www.google.com/', {
        headers,
        signal: AbortSignal.timeout(8000)
      })
      const setCookie = initRes.headers.get('set-cookie')
      if (setCookie) {
        const cookies = setCookie.split(',').map(c => c.trim().split(';')[0])
        headers['Cookie'] = cookies.join('; ')
      }
      headers['Referer'] = 'https://www.google.com/'
      await new Promise(r => setTimeout(r, 800 + Math.random() * 700))
    } catch (_) {}

    const searchUrl = new URL('https://www.google.com/search')
    searchUrl.searchParams.set('q', query)
    searchUrl.searchParams.set('tbm', 'isch')
    searchUrl.searchParams.set('hl', 'es')
    searchUrl.searchParams.set('gl', 'es')
    searchUrl.searchParams.set('num', '30')
    searchUrl.searchParams.set('source', 'lnms')

    const res = await fetch(searchUrl.toString(), {
      headers,
      redirect: 'follow',
      signal: AbortSignal.timeout(12000)
    })

    if (res.status === 429) throw new Error('Google rate limit (429)')
    if (res.status === 403) throw new Error('Google bloqueó la IP (403)')
    if (!res.ok) throw new Error(`Google HTTP ${res.status}`)

    const html = await res.text()

    if (html.includes('detected unusual traffic') || html.includes('recaptcha')) {
      throw new Error('Google CAPTCHA detectado')
    }

    const imageUrls = new Set()

    // Extraer URLs del JSON embebido en el HTML
    for (const match of html.matchAll(/\["(https?:\/\/[^"]+)",(\d+),(\d+)\]/g)) {
      const url = match[1]
      if (url && !url.includes('google.com') && !url.includes('gstatic.com') &&
          /\.(jpg|jpeg|png|gif|webp|bmp)/i.test(url)) {
        imageUrls.add(url)
      }
    }

    // Regex de respaldo
    for (const match of html.matchAll(/"ou":"(https?:\/\/[^"]+)"/g)) {
      imageUrls.add(match[1])
    }
    for (const match of html.matchAll(/imgurl=(https?[^&]+)/g)) {
      imageUrls.add(decodeURIComponent(match[1]))
    }

    return [...imageUrls].slice(0, limit).map(url => ({
      title: query,
      image: url,
      thumbnail: url,
      source: '',
      width: null,
      height: null
    }))
  }

  // ─── Función principal con fallback automático ────────────────────────────
  async function getImages (query, limit = 20) {
    // Intenta DDG primero, si falla usa Google scraping
    try {
      const results = await searchDDG(query, limit)
      if (results.length > 0) return { results, method: 'duckduckgo' }
    } catch (e) {
      // fallback
    }

    const results = await searchGoogle(query, limit)
    return { results, method: 'google-scraping' }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  GET /search/google-image?q=gatos&limit=20
  // ─────────────────────────────────────────────────────────────────────────
  app.get('/search/google-image', async (req, res) => {
    try {
      const { q, limit = 15 } = req.query

      if (!q) {
        return res.status(400).json({
          status: false,
          message: "Missing parameter 'q'"
        })
      }

      const maxResults = Math.min(parseInt(limit) || 20, 50)
      const { results, method } = await getImages(q, maxResults)

      if (!results.length) {
        return res.status(404).json({
          status: false,
          message: 'No images found'
        })
      }

      res.json({
        status: true,
        method,
        count: results.length,
        result: results
      })

    } catch (e) {
      res.status(500).json({
        status: false,
        message: e.message
      })
    }
  })

}
