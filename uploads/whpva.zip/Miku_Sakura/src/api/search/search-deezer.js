const axios = require('axios');

module.exports = function(app) {

  app.get('/search/deezer', async (req, res) => {
    try {
      const { q, limit } = req.query;
      if (!q || !limit) {
        return res.status(400).json({
          status: false,
          error: "Parámetros requeridos: ?q= &limit="
        });
      }

      const numLimit = parseInt(limit);
      if (isNaN(numLimit) || numLimit <= 0) {
        return res.status(400).json({
          status: false,
          error: "El parámetro limit debe ser un número válido mayor a 0"
        });
      }

      const { data } = await axios.get('https://api.deezer.com/search', {
        params: {
          q,
          limit: numLimit
        },
        timeout: 10000
      });

      if (!data?.data?.length) {
        return res.json({
          status: false,
          error: "No hay resultados"
        });
      }

      const results = data.data.map(v => ({
        id: v.id,
        title: v.title,
        duration: v.duration,
        preview: v.preview,
        link: v.link,

        artist: {
          name: v.artist?.name,
          id: v.artist?.id,
          link: v.artist?.link,
          picture: v.artist?.picture_medium
        },

        album: {
          title: v.album?.title,
          id: v.album?.id,
          cover: v.album?.cover_medium,
          cover_big: v.album?.cover_big
        },

        type: v.type
      }));

      res.json({
        status: true,
        total: results.length,
        data: results
      });

    } catch (err) {
      res.status(500).json({
        status: false,
        error: "Error en Deezer search",
        detail: err.message
      });
    }
  });

};