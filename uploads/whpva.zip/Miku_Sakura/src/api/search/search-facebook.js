const fetch = require("node-fetch")

module.exports = function(app) {

  const q = ""
  const limit = 30

  const cookies = [
    { "name": "datr", "value": "3H0KagKVy04s29ssF98-WSmO" },
    { "name": "sb", "value": "3H0KajCaDC3fIQ7DCs7TmE8k" },
    { "name": "c_user", "value": "61589734632097" },
    { "name": "xs", "value": "48%3ArnyxX0VX-Zfo6w%3A2%3A1779072562%3A-1%3A-1%3A%3AAcwvd6NMHQS0Y3aIbYnB81X24lTq698wJ7MkORPYHA" },
    { "name": "fr", "value": "1EJ4nDpNhzRoDMyyi.AWdKEdDm8izeYubi1NZIxfRag1Yvc5Y1KHejjLiDoDtVAjbh50k.BqCn5M..AAA.0.0.BqCn5P.AWexcoYrrh2Zz15vIPTfrweQw2c" },
    { "name": "presence", "value": "C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1779072597776%2C%22v%22%3A1%7D" },
    { "name": "wd", "value": "1366x633" }
  ]

  const ua =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

  const base = "https://www.facebook.com"

  const graphql_url = `${base}/api/graphql/`

  const search_doc_id = "27004494905847061"

  function getCookieString() {
    return cookies.map(c => `${c.name}=${c.value}`).join("; ")
  }

  async function getSessionTokens() {

    const cookieStr = getCookieString()

    const res = await fetch(base, {
      headers: {
        "User-Agent": ua,
        "Accept":
          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "es-LA,es;q=0.9",
        "sec-ch-ua":
          '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "Cookie": cookieStr
      }
    })

    const html = await res.text()

    const extract = p => {
      const m = html.match(p)
      return m ? m[1] : ""
    }

    const fb_dtsg =
      extract(/\["DTSGInitData",\[\],\{"token":"([^"]+)"/) ||
      extract(/"dtsg":\{"token":"([^"]+)"/)

    const lsd =
      extract(/\["LSD",\[\],\{"token":"([^"]+)"/) ||
      extract(/name="lsd"\s+value="([^"]+)"/)

    const hsi =
      extract(/"hsi":"(\d+)"/) ||
      Date.now().toString()

    const rev =
      extract(/"server_revision":(\d+)/) ||
      extract(/"__spin_r":(\d+)/) ||
      "1039686045"

    const jazoest =
      extract(/jazoest=(\d+)/) ||
      extract(/"jazoest["\s:]+(\d+)/) ||
      "25227"

    const hs =
      extract(/"haste_session":"([^"]+)"/) ||
      "20591.HYP:comet_pkg.2.1...0"

    const userId =
      extract(/"USER_ID":"(\d+)"/)

    if (!fb_dtsg || !userId || userId === "0") {
      throw new Error("Cookies inválidas o expiradas")
    }

    return {
      fb_dtsg,
      lsd,
      hsi,
      rev,
      jazoest,
      hs,
      userId,
      cookieStr
    }
  }

  function buildSearchVariables(query, lim) {

    return {
      allow_streaming: false,
      args: {
        callsite: "COMET_GLOBAL_SEARCH",
        config: {
          exact_match: false
        },
        context: {
          bsid: "8095a9e1-65db-41f1-8432-6174ee177dbf",
          tsid: Math.random().toString()
        },
        experience: {
          client_defined_experiences: [
            "ADS_PARALLEL_FETCH"
          ],
          encoded_server_defined_params: null,
          fbid: null,
          type: "GLOBAL_SEARCH"
        },
        filters: [],
        text: query
      },
      count: lim,
      cursor: null,
      feedLocation: "SEARCH",
      feedbackSource: 23,
      fetch_filters: true,
      renderLocation: "search_results_page",
      scale: 1
    }
  }

  function buildBody(
    tokens,
    friendlyName,
    docId,
    variables
  ) {

    const p = new URLSearchParams()

    p.set("av", tokens.userId)
    p.set("__user", tokens.userId)
    p.set("__a", "1")
    p.set("__req", "a")
    p.set("__hs", tokens.hs)
    p.set("dpr", "1")
    p.set("__ccg", "GOOD")
    p.set("__rev", tokens.rev)
    p.set("__hsi", tokens.hsi)
    p.set("__comet_req", "15")
    p.set("fb_dtsg", tokens.fb_dtsg)
    p.set("jazoest", tokens.jazoest)
    p.set("lsd", tokens.lsd)
    p.set("fb_api_caller_class", "RelayModern")
    p.set("fb_api_req_friendly_name", friendlyName)
    p.set("variables", JSON.stringify(variables))
    p.set("server_timestamps", "true")
    p.set("doc_id", docId)

    return p.toString()
  }

  function parseEdges(text) {

    const users = []
    const videos = []
    const photos = []

    for (const line of text.split("\n")) {

      try {

        const j = JSON.parse(
          line.replace("for (;;);", "")
        )

        const edges =
          j?.data?.serpResponse?.results?.edges || []

        for (const edge of edges) {

          const node = edge.node || {}

          if (
            node.__typename === "User" ||
            node.__typename === "Page"
          ) {

            users.push({
              id: node.id || "",
              name: node.name || "",
              verified:
                node.is_verified || false,
              url:
                node.url ||
                `https://facebook.com/${node.id}`,
              avatar:
                node.profile_picture?.uri || ""
            })
          }

          const raw = JSON.stringify(edge)

          const video =
            raw.match(/"playable_url":"([^"]+)"/)

          const image =
            raw.match(/"image":\{"uri":"([^"]+)"/)

          const textMatch =
            raw.match(/"text":"([^"]+)"/)

          if (video) {

            videos.push({
              text: textMatch
                ? textMatch[1]
                : "",
              download:
                video[1].replace(/\\/g, ""),
              hd:
                (
                  raw.match(
                    /"playable_url_quality_hd":"([^"]+)"/
                  ) || []
                )[1]?.replace(/\\/g, "") || "",
              thumbnail:
                (
                  raw.match(
                    /"preferred_thumbnail":\{"image":\{"uri":"([^"]+)"/
                  ) || []
                )[1]?.replace(/\\/g, "") || ""
            })
          }

          if (image) {

            photos.push({
              text: textMatch
                ? textMatch[1]
                : "",
              image:
                image[1].replace(/\\/g, "")
            })
          }

        }

      } catch {}

    }

    return {
      users,
      videos,
      photos
    }
  }

  async function buscarFacebook(query, lim) {

    const tokens = await getSessionTokens()

    const variables =
      buildSearchVariables(query, lim)

    const body = buildBody(
      tokens,
      "SearchCometResultsPaginatedResultsQuery",
      search_doc_id,
      variables
    )

    const res = await fetch(graphql_url, {
      method: "POST",
      headers: {
        "User-Agent": ua,
        "Content-Type":
          "application/x-www-form-urlencoded",
        "Accept": "*/*",
        "Referer":
          `${base}/search/top/?q=${encodeURIComponent(query)}`,
        "x-fb-friendly-name":
          "SearchCometResultsPaginatedResultsQuery",
        "x-fb-lsd": tokens.lsd,
        "x-asbd-id": "359341",
        "sec-ch-ua":
          '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "Origin": base,
        "Cookie": tokens.cookieStr
      },
      body
    })

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`)
    }

    const text = await res.text()

    return parseEdges(text)
  }

  app.get("/search/facebook", async (req, res) => {

    try {
      const {
        q,
        limit = 30
      } = req.query

      if (!q) {
        return res.status(400).json({
          status: false,
          message: "Falta el parámetro q"
        })
      }

      const result =
        await buscarFacebook(
          q,
          Number(limit)
        )

      return res.json({
        status: true,
        query: q,
        limit: Number(limit),
        stats: {
          users: result.users.length,
          videos: result.videos.length,
          photos: result.photos.length
        },
        result
      })

    } catch (e) {

      return res.status(500).json({
        status: false,
        message: e.message
      })

    }

  })

}