const axios = require('axios')
const cheerio = require('cheerio')

async function getRealTelegramLink(joinUrl) {
  try {
    const { data } = await axios.get(joinUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36'
      }
    })

    const $ = cheerio.load(data)

    const realLink = $('a[href^="tg://resolve"]').attr('href')

    if (realLink) {
      const username =
        realLink.split('tg://resolve?domain=')[1]

      return `https://t.me/${username}`
    }

  } catch (e) {
    console.error('Error real link:', e.message)
  }

  return joinUrl
}

async function searchTelegramChannels(query) {
  try {
    const url =
      `https://en.tgramsearch.com/search?query=${encodeURIComponent(query)}`

    const { data } = await axios.get(url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36'
      }
    })

    const $ = cheerio.load(data)

    const results = []

    for (const el of $('.tg-channel-wrapper').toArray()) {

      const name =
        $(el).find('.tg-channel-link a').text().trim()

      let link =
        $(el).find('.tg-channel-link a').attr('href')

      const image =
        $(el).find('.tg-channel-img img').attr('src')

      const members =
        $(el).find('.tg-user-count').text().trim()

      const description =
        $(el).find('.tg-channel-description').text().trim()

      const category =
        $(el).find('.tg-channel-categories a').text().trim()

      if (link?.startsWith('/join/')) {

        link = await getRealTelegramLink(
          `https://en.tgramsearch.com${link}`
        )

      } else if (link?.startsWith('tg://resolve?domain=')) {

        const username =
          link.split('tg://resolve?domain=')[1]

        link = `https://t.me/${username}`
      }

      results.push({
        name,
        link,
        image,
        members,
        description,
        category
      })
    }

    return results

  } catch (err) {
    console.error('Scrape error:', err.message)
    return []
  }
}

module.exports = function (app) {

  app.get('/search/telegram-channel', async (req, res) => {
    try {
      const { q } = req.query

      if (!q) {
        return res.status(400).json({
          status: false,
          message: "Falta el parámetro 'q'"
        })
      }

      const results =
        await searchTelegramChannels(q)

      res.json({
        status: true,
        total: results.length,
        result: results.slice(0, 10)
      })

    } catch (e) {
      res.status(500).json({
        status: false,
        message: e.message
      })
    }
  })

}