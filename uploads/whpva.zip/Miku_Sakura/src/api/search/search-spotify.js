const axios  = require("axios")
const crypto = require("crypto")

class Spotify {
  constructor() {
    this.cfg = {
      secret:         "376136387538459893883312310911992847112448894410210511297108",
      version:        61,
      client_version: "1.2.88.61.ge172202b",
      queries: {
        search: { opt: "searchDesktop",      sha: "21b3fe49546912ba782db5c47e9ef5a7dbd20329520ba0c7d0fcfadee671d24e" },
        track:  { opt: "getTrack",           sha: "612585ae06ba435ad26369870deaae23b5c8800a256cd8a57e08eddc25a37294" }
      }
    }

    this.is = axios.create({
      headers: {
        referer:        "https://open.spotify.com/",
        origin:         "https://open.spotify.com",
        "content-type": "application/json",
        accept:         "application/json",
        "user-agent":   "Mozilla/5.0 (Linux; Android 16; NX729J) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.7499.34 Mobile Safari/537.36"
      }
    })
  }

  // ── TOTP ────────────────────────────────────────────────────────────────────
  _totp(tsms) {
    const buf = Buffer.alloc(8)
    buf.writeBigInt64BE(BigInt(Math.floor((tsms / 1000) / 30)))
    const digest = crypto.createHmac("sha1", Buffer.from(this.cfg.secret, "utf8")).update(buf).digest()
    const off    = digest[digest.length - 1] & 0xf
    return ((digest.readUInt32BE(off) & 0x7fffffff) % 1000000).toString().padStart(6, "0")
  }

  // ── Token ───────────────────────────────────────────────────────────────────
  async getToken() {
    if (this.is.defaults.headers.authorization) return
    const sts = Math.floor(Date.now() / 1000)

    const { data: tk } = await this.is.get("https://open.spotify.com/api/token", {
      params: { reason: "init", productType: "web-player", totp: this._totp(Date.now()), totpServer: this._totp(sts * 1000), totpVer: String(this.cfg.version) }
    })

    const { data: cl } = await this.is.post("https://clienttoken.spotify.com/v1/clienttoken", {
      client_data: {
        client_version: this.cfg.client_version,
        client_id:      tk.clientId,
        js_sdk_data: { device_brand: "unknown", device_model: "unknown", os: "linux", os_version: "24.04", device_id: crypto.randomUUID(), device_type: "computer" }
      }
    })

    Object.assign(this.is.defaults.headers, {
      "accept-language": "en", "app-platform": "WebPlayer",
      authorization:     `Bearer ${tk.accessToken}`,
      "client-token":    cl.granted_token.token,
      "spotify-app-version": this.cfg.client_version
    })
  }

  // ── Query genérico ──────────────────────────────────────────────────────────
  async _query(name, variables) {
    await this.getToken()
    const q = this.cfg.queries[name]
    const { data } = await this.is.post("https://api-partner.spotify.com/pathfinder/v2/query", {
      variables,
      operationName: q.opt,
      extensions: { persistedQuery: { version: 1, sha256Hash: q.sha } }
    })
    return data
  }

  // ── Helpers ─────────────────────────────────────────────────────────────────
  _link(uri) {
    if (!uri) return { id: null, url: null }
    const p = uri.split(":")
    return { id: p[2] || null, url: p[2] ? `https://open.spotify.com/${p[1]}/${p[2]}` : null }
  }

  _img(o) {
    return (o?.sources || o?.items || [])[0]?.url || null
  }

  _dur(ms) {
    const m = Math.floor(ms / 60000)
    const s = String(Math.floor((ms % 60000) / 1000)).padStart(2, "0")
    return `${m}:${s}`
  }

  // ── Search (solo IDs rápido) ────────────────────────────────────────────────
  async search(query, limit = 8) {
    const res = await this._query("search", {
      searchTerm: query, offset: 0, limit,
      numberOfTopResults: 5, includeAudiobooks: true,
      includeArtistHasConcertsField: false, includePreReleases: true,
      includeAuthors: false, includeEpisodeContentRatingsV2: false
    })

    const items = res.data.searchV2?.tracksV2?.items || []
    return items.map(node => node.item?.data).filter(Boolean)
  }

  // ── Track detalle ───────────────────────────────────────────────────────────
  async track(id) {
    const res = await this._query("track", { uri: `spotify:track:${id}` })
    const t   = res.data.trackUnion
    if (!t) return null

    const allArtists = [
      ...(t.firstArtist?.items || []),
      ...(t.otherArtists?.items || [])
    ]

    return {
      id:          this._link(t.uri).id,
      title:       t.name || null,
      duration:    this._dur(t.duration?.totalMilliseconds || 0),
      duration_ms: t.duration?.totalMilliseconds || 0,
      playcount:   parseInt(t.playcount) || null,
      explicit:    t.contentRating?.label === "EXPLICIT",
      type:        t.trackMediaType || "AUDIO",
      link:        this._link(t.uri).url,

      // 👤 Artistas
      artists: allArtists.map(a => ({
        id:   this._link(a.uri).id,
        name: a.profile?.name || null,
        url:  this._link(a.uri).url,
        image: this._img(a.visuals?.avatarImage)
      })),

      // 💿 Álbum
      album: {
        id:           this._link(t.albumOfTrack?.uri).id,
        name:         t.albumOfTrack?.name || null,
        url:          this._link(t.albumOfTrack?.uri).url,
        type:         t.albumOfTrack?.type || null,
        release_date: t.albumOfTrack?.date?.isoString || t.albumOfTrack?.date?.year || null,
        image:        this._img(t.albumOfTrack?.coverArt)
      },

      // 🎵 Preview
      preview_url: t.previews?.audioPreviews?.items?.[0]?.url || null
    }
  }
}

// ─── Endpoint ─────────────────────────────────────────────────────────────────

module.exports = function (app) {

  app.get("/search/spotify", async (req, res) => {
    try {
      const { q, limit = 8 } = req.query

      if (!q?.trim())
        return res.status(400).json({ status: false, message: "Falta ?q=" })

      const sp = new Spotify()

      // 1️⃣ Buscar tracks (rápido, solo data básica del search)
      const searchItems = await sp.search(q, Number(limit))

      // 2️⃣ Para cada track buscar detalle en paralelo (trae playcount, fecha, artistas completos)
      const details = await Promise.allSettled(
        searchItems.map(t => {
          const id = t.uri?.split(":")?.[2]
          return id ? sp.track(id) : Promise.resolve(null)
        })
      )

      const result = details.map((d, i) => {
        if (d.status === "fulfilled" && d.value) return d.value

        // fallback con lo del search si falla el detalle
        const t = searchItems[i]
        const id = t.uri?.split(":")?.[2]
        return {
          id,
          title:    t.name || null,
          duration: sp._dur(t.duration?.totalMilliseconds || 0),
          artists:  (t.artists?.items || []).map(a => ({ name: a.profile?.name })),
          album:    { name: t.albumOfTrack?.name, image: sp._img(t.albumOfTrack?.coverArt) },
          link:     id ? `https://open.spotify.com/track/${id}` : null
        }
      }).filter(Boolean)

      return res.json({ status: true, total: result.length, result })

    } catch (e) {
      return res.status(500).json({ status: false, message: e.message })
    }
  })

}
