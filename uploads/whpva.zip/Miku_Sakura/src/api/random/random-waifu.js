const axios = require("axios")

module.exports = function (app) {

  const SFW_TYPES = [
    "waifu",
    "neko",
    "shinobu",
    "megumin"
  ]

  // 🔹 Tipos disponibles
  app.get("/random/types", (req, res) => {
    res.json({
      status: true,
      types: SFW_TYPES
    })
  })

  // 🔹 Random Waifu usando nekos.best
  app.get("/random/waifu", async (req, res) => {
    try {

      const type = SFW_TYPES[
        Math.floor(Math.random() * SFW_TYPES.length)
      ]

      const { data } = await axios.get(
        `https://nekos.best/api/v2/${type}`
      )

      const result = data.results?.[0]

      if (!result?.url) {
        return res.status(500).json({
          status: false,
          message: "No se pudo obtener imagen"
        })
      }

      const extension = result.url
        .split(".")
        .pop()
        .split("?")[0]

      return res.json({
        status: true,
        result: {
          name: `waifu_${Date.now()}.${extension}`,
          extension,
          type,
          artist_name: result.artist_name || null,
          artist_href: result.artist_href || null,
          anime_name: result.anime_name || null,
          source_url: result.source_url || null,
          dl_url: result.url
        },
        timestamp_ms: Date.now(),
        timestamp_iso: new Date().toISOString()
      })

    } catch (e) {
      return res.status(500).json({
        status: false,
        message: e.response?.data || e.message
      })
    }
  })

}