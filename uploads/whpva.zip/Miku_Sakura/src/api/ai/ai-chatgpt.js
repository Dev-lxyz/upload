const crypto = require("crypto");

let _fetch = globalThis.fetch;
if (!_fetch) {
  _fetch = (...args) => import("undici").then(({ fetch }) => fetch(...args));
}

let _perf = globalThis.performance;
if (!_perf) {
  _perf = require("perf_hooks").performance;
}

// ─── ChatGPT Scraper (self-contained) ───────────────────────────────────────

class ChatGPT {
  constructor() {
    this.baseUrl     = "https://chatgpt.com";
    this.userAgent   = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36";
    this.oaiDid      = crypto.randomUUID();
    this.screenWidth  = 423;
    this.screenHeight = 965;
    this.lang         = "id-ID";
    this.buildNumber  = "prod-69a06c53754594935887d6c16b844885964a78fc";
  }

  _headers(extra = {}) {
    return {
      "User-Agent":          this.userAgent,
      "accept":              "*/*",
      "accept-language":     `${this.lang},en-US;q=0.9,en;q=0.8`,
      "content-type":        "application/json",
      "OAI-Device-Id":       this.oaiDid,
      "sec-ch-ua":           '"Chromium";v="144", "Not/A)Brand";v="24"',
      "sec-ch-ua-mobile":    "?1",
      "sec-ch-ua-platform":  '"Android"',
      "sec-fetch-dest":      "empty",
      "sec-fetch-mode":      "cors",
      "sec-fetch-site":      "same-origin",
      "origin":              "https://chatgpt.com",
      "referer":             "https://chatgpt.com/",
      ...extra,
    };
  }

  _fnv1a(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    h ^= h >>> 16; h = Math.imul(h, 2246822507) >>> 0;
    h ^= h >>> 13; h = Math.imul(h, 3266489909) >>> 0;
    h ^= h >>> 16;
    return (h >>> 0).toString(16).padStart(8, "0");
  }

  _encodeConfig(cfg) {
    return Buffer.from(JSON.stringify(cfg)).toString("base64");
  }

  _makeBrowserConfig() {
    return [
      this.screenWidth + this.screenHeight,
      String(new Date()),
      2172649472, 0,
      this.userAgent, null,
      this.buildNumber,
      this.lang, `${this.lang},en`,
      0, "contacts−[object ContactsManager]",
      "_reactListening", "User",
      _perf.now(), crypto.randomUUID(), "",
      8, _perf.timeOrigin,
      0, 0, 0, 0, 0, 0, 0,
    ];
  }

  _computePow(seed, difficulty, cfg) {
    const start = _perf.now();
    for (let i = 0; i < 500000; i++) {
      cfg[3] = i;
      cfg[9] = Math.round(_perf.now() - start);
      const encoded = this._encodeConfig(cfg);
      if (this._fnv1a(seed + encoded).substring(0, difficulty.length) <= difficulty) {
        return "gAAAAAB" + encoded + "~S";
      }
    }
    return "wQ8Lk5FbGpA2NcR9dShT6gYjU7VxZ4De";
  }

  async _generateSentinelTokens() {
    const initCfg = this._makeBrowserConfig();
    initCfg[3] = 1; initCfg[9] = 0;
    const initToken = "gAAAAAC" + this._encodeConfig(initCfg);

    const prepareRes = await _fetch(
      `${this.baseUrl}/backend-anon/sentinel/chat-requirements/prepare`,
      { method: "POST", headers: this._headers(), body: JSON.stringify({ p: initToken }) }
    ).then(r => r.json());

    let pow = null;
    if (prepareRes.proofofwork?.required) {
      pow = this._computePow(
        prepareRes.proofofwork.seed,
        prepareRes.proofofwork.difficulty,
        this._makeBrowserConfig()
      );
    }

    const turnstile = crypto.randomBytes(Math.floor((2256 / 4) * 3)).toString("base64").slice(0, 2256);

    const finalizeBody = { prepare_token: prepareRes.prepare_token ?? "" };
    if (pow)       finalizeBody.proofofwork = pow;
    if (turnstile) finalizeBody.turnstile   = turnstile;

    const finalizeRes = await _fetch(
      `${this.baseUrl}/backend-anon/sentinel/chat-requirements/finalize`,
      { method: "POST", headers: this._headers(), body: JSON.stringify(finalizeBody) }
    ).then(r => r.json());

    return { pow, turnstile, chatRequirementsToken: finalizeRes.token ?? null };
  }

  async _getConduitToken(message, msgId, { conversationId, parentMsgId }) {
    const body = {
      action: "next",
      fork_from_shared_post: false,
      parent_message_id: parentMsgId,
      model: "auto",
      timezone_offset_min: new Date().getTimezoneOffset(),
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      conversation_mode: { kind: "primary_assistant" },
      system_hints: [],
      supports_buffering: true,
      supported_encodings: ["v1"],
      partial_query: {
        id: msgId,
        author: { role: "user" },
        content: { content_type: "text", parts: [message] },
      },
      client_contextual_info: { app_name: "chatgpt.com" },
    };
    if (conversationId) body.conversation_id = conversationId;

    const res = await _fetch(
      `${this.baseUrl}/backend-anon/f/conversation/prepare`,
      { method: "POST", headers: this._headers({ "X-Conduit-Token": "no-token" }), body: JSON.stringify(body) }
    );
    const data = await res.json();
    return data.token ?? data.conduit_token;
  }

  _buildMessageBody(message, msgId, { conversationId, parentMsgId }) {
    const body = {
      action: "next",
      messages: [{
        id: msgId,
        author: { role: "user" },
        create_time: Date.now() / 1000,
        content: { content_type: "text", parts: [message] },
        metadata: {
          selected_github_repos: [],
          selected_all_github_repos: false,
          serialization_metadata: { custom_symbol_offsets: [] },
        },
      }],
      parent_message_id: parentMsgId,
      model: "auto",
      timezone_offset_min: new Date().getTimezoneOffset(),
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      conversation_mode: { kind: "primary_assistant" },
      enable_message_followups: true,
      system_hints: [],
      supports_buffering: true,
      supported_encodings: ["v1"],
      client_contextual_info: {
        is_dark_mode: true,
        time_since_loaded: 10,
        page_height: 845,
        page_width: 423,
        pixel_ratio: 1.7,
        screen_height: this.screenHeight,
        screen_width: this.screenWidth,
        app_name: "chatgpt.com",
      },
      no_auth_ad_preferences: { personalization_enabled: true, history_enabled: true },
      paragen_cot_summary_display_override: "allow",
      force_parallel_switch: "auto",
    };
    if (conversationId) body.conversation_id = conversationId;
    return body;
  }

  async _parseSSE(body) {
    const decoder = new TextDecoder();
    let buf = "", fullText = "", title = null, model = null, convId = null, msgId = null;

    for await (const chunk of body) {
      buf += decoder.decode(chunk, { stream: true });
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";

      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const raw = line.slice(5).trim();
        if (!raw || raw === "[DONE]") continue;

        let json;
        try { json = JSON.parse(raw); } catch { continue; }

        if (json.conversation_id)        convId = json.conversation_id;
        else if (json.v?.conversation_id) convId = json.v.conversation_id;

        if (json.v?.message?.author?.role === "assistant" && json.v.message?.id)
          msgId = json.v.message.id;

        if (json.type === "title_generation")   title = json.title;
        if (json.type === "server_ste_metadata") model = json.metadata?.model_slug ?? null;

        for (const p of (Array.isArray(json.v) ? json.v : [])) {
          if (p.o === "append" && p.p?.includes("/message/content/parts/0")) {
            fullText += p.v;
          }
        }
      }
    }

    return { text: fullText.trim(), title, model, conversationId: convId, messageId: msgId };
  }

  async send(message, opts = {}) {
    const { conversationId = null, parentMessageId = null } = opts;
    const parentMsgId = parentMessageId ?? "client-created-root";
    const msgId = crypto.randomUUID();

    const [tokens, conduitToken] = await Promise.all([
      this._generateSentinelTokens(),
      this._getConduitToken(message, msgId, { conversationId, parentMsgId }),
    ]);

    const body = this._buildMessageBody(message, msgId, { conversationId, parentMsgId });

    const res = await _fetch(`${this.baseUrl}/backend-anon/f/conversation`, {
      method: "POST",
      body: JSON.stringify(body),
      headers: this._headers({
        accept: "text/event-stream",
        "OAI-Language": this.lang,
        "OpenAI-Sentinel-Chat-Requirements-Token": tokens.chatRequirementsToken,
        "OpenAI-Sentinel-Turnstile-Token": tokens.turnstile,
        "OpenAI-Sentinel-Proof-Token": tokens.pow,
        "X-Conduit-Token": conduitToken,
      }),
    });

    if (!res.ok) {
      const err = await res.text().catch(() => "(no body)");
      throw new Error(`HTTP ${res.status}: ${err}`);
    }

    const parsed = await this._parseSSE(res.body);

    return {
      question:       message,
      answer:         parsed.text,
      title:          parsed.title,
      model:          parsed.model,
      conversationId: parsed.conversationId,
      messageId:      parsed.messageId,
    };
  }
}

// ─── Endpoint ────────────────────────────────────────────────────────────────

module.exports = function (app) {

  const sessions = new Map(); // conversationId → { conversationId, parentMessageId }

  app.get("/ai/chatgpt", async (req, res) => {
    try {
      const { text, conversation_id } = req.query;

      if (!text?.trim()) {
        return res.status(400).json({ status: false, message: "Falta el parámetro ?text=" });
      }

      const session = conversation_id && sessions.has(conversation_id)
        ? sessions.get(conversation_id)
        : {};

      const client = new ChatGPT();

      const result = await client.send(text, {
        conversationId:  session.conversationId  ?? null,
        parentMessageId: session.parentMessageId ?? null,
      });

      // guardar sesión para multi-turn
      if (result.conversationId) {
        sessions.set(result.conversationId, {
          conversationId:  result.conversationId,
          parentMessageId: result.messageId,
        });
      }

      return res.json({
        status:         true,
        model:          result.model          ?? "auto",
        title:          result.title          ?? null,
        conversationId: result.conversationId ?? null,
        messageId:      result.messageId      ?? null,
        question:       result.question,
        answer:         result.answer,
      });

    } catch (e) {
      return res.status(500).json({ status: false, message: e.message });
    }
  });

};
