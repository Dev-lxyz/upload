module.exports = function (app) {
  const { chat } = require('../../lib/gemini-v2')

  app.get('/ai/gemini/v2', async (req, res) => {
    try {
      const { text, prompt } = req.query

      const input = text || prompt

      if (!input) {
        return res.status(400).json({
          status: false,
          message: "Falta el parámetro 'text' o 'prompt'"
        })
      }

      return res.json({
        status: true,
        data: {
          response: await chat(input)
        }
      })

    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message || 'Error en Gemini V2'
      })
    }
  })
}