module.exports = function (app) {
  const axios = require("axios");
  const { wrapper } = require("axios-cookiejar-support");
  const { CookieJar } = require("tough-cookie");

  const BASE = "https://j2download.com";
  const UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36";

  const jar = new CookieJar();

  const client = wrapper(axios.create({
    jar,
    withCredentials: true,
    timeout: 15000
  }));

  async function getTokens() {
    await client.get(BASE, {
      headers: {
        "user-agent": UA,
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
      },
    });

    const cookies = await jar.getCookies(BASE);

    const apiToken = cookies.find(c => c.key === "api_token")?.value;
    const csrfToken = cookies.find(c => c.key === "csrf_token")?.value;

    if (!apiToken || !csrfToken) {
      throw new Error("Gagal ambil token");
    }

    return { apiToken, csrfToken };
  }

  async function spotifydl(url) {
    const { apiToken, csrfToken } = await getTokens();

    const res = await client.post(`${BASE}/api/autolink`, {
      data: {
        url,
        unlock: true
      },
    }, {
      headers: {
        "accept": "application/json, text/plain, */*",
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        "content-type": "application/json",
        "user-agent": UA,
        "origin": BASE,
        "referer": `${BASE}/`,
        "x-csrf-token": csrfToken,
        "cookie": `api_token=${apiToken}; csrf_token=${csrfToken}`,
      },
    });

    return res.data;
  }

  app.get("/download/spotify/v3", async (req, res) => {
    try {
      const { url } = req.query;

      if (!url) {
        return res.status(400).json({
          status: false,
          error: "Falta el parámetro ?url="
        });
      }

      const data = await spotifydl(url);

      const result = data?.medias?.[0] || {};

      res.json({
        status: true,
        creator: "nath",
        result: {
          title: data?.title || null,
          thumbnail: data?.thumbnail || null,
          duration: data?.duration || null,
          source: data?.source || "Spotify",
          type: result?.extension || "mp3",
          quality: result?.quality || null,
          size: result?.formattedSize || null,
          download: result?.url || null
        }
      });

    } catch (err) {
      console.error("[SPOTIFY DL]", err.response?.data || err.message);

      res.status(500).json({
        status: false,
        error: "Error al descargar Spotify"
      });
    }
  });
};