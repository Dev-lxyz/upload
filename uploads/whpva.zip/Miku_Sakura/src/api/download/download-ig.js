/*
* Instagram Downloader Endpoint
* By: shadow
*/

const { instagram } = require('../../lib/instagram')

module.exports = function(app) {

  app.get('/download/instagram', async (req, res) => {
    const { url, type = 'video' } = req.query

    if (!url) {
      return res.status(400).json({
        status: false,
        error: 'Falta parámetro ?url='
      })
    }

    try {
      let result

      if (type === 'slide') {
        result = await instagram.slide(url)
      } else {
        result = await instagram.video(url)
      }

      if (!result.status) {
        return res.status(500).json(result)
      }

      res.json({
        status: true,
        type,
        result: result.result
      })

    } catch (err) {
      res.status(500).json({
        status: false,
        error: 'Error Instagram',
        detail: err.message
      })
    }
  })

}