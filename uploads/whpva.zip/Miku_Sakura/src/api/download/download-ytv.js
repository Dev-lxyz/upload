const axios = require("axios")

module.exports = function (app) {

  async function ytdl(url, format = "mp3") {
    try {
      const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/
      const match = url.match(regex)

      if (!match || !match[1]) {
        throw new Error("URL de YouTube inválida")
      }

      const client = axios.create({
        headers: {
          "User-Agent": "Mozilla/5.0 (Linux; Android 16; NX729J) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.7271.123 Mobile Safari/537.36",
          "Referer": "https://id.ytmp3.mobi/"
        },
        timeout: 30000
      })

      const { data: init } = await client.get(
        "https://d.ymcdn.org/api/v1/init",
        {
          params: {
            p: "y",
            "23": "1llum1n471",
            _: Math.random()
          }
        }
      )

      if (!init.convertURL) {
        throw new Error("No se pudo iniciar el servidor")
      }

      const { data: convert } = await client.get(
        init.convertURL,
        {
          params: {
            v: match[1],
            f: format,
            _: Math.random()
          }
        }
      )

      let progress = 0
      let title = ""
      let attempts = 0
      const maxAttempts = 20

      while (progress < 3 && attempts < maxAttempts) {

        const { data } = await client.get(convert.progressURL)

        if (data.error > 0) {
          throw new Error(`Error del servidor: ${data.error}`)
        }

        progress = data.progress
        title = data.title

        if (progress < 3) {
          attempts++
          await new Promise(r => setTimeout(r, 250))
        }
      }

      if (attempts >= maxAttempts) {
        throw new Error("Tiempo de espera agotado")
      }

      return {
        status: true,
        data: {
          title, 
          format,
          dl: convert.downloadURL
        }
      }

    } catch (e) {

      return {
        status: false,
        message: e.message
      }

    }
  }

  app.get("/download/ytmp4", async (req, res) => {
    try {
      const {
        url,
        format = "mp4"
      } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          message: "Falta el parámetro url"
        })
      }

      if (!["mp3", "mp4"].includes(format)) {
        return res.status(400).json({
          status: false,
          message: "Formato válido: mp3 o mp4"
        })
      }

      const result = await ytdl(url, format)
      return res.json(result)
    } catch (e) {

      return res.status(500).json({
        status: false,
        message: e.message
      })

    }
  })

}