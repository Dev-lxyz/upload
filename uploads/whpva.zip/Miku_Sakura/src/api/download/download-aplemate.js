const axios = require("axios")
const cheerio = require("cheerio")
const FormData = require("form-data")

module.exports = function (app) {

  async function aplemate(urls) {
    const baseUrl = "https://aplmate.com"

    const baseHeaders = {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",

      "X-Requested-With": "XMLHttpRequest"
    }

    try {
      const handshake = await axios.get(baseUrl, {
        headers: baseHeaders
      })

      const cookie =
        handshake.headers["set-cookie"]
          ?.map(c => c.split(";")[0])
          .join("; ") || ""

      const headers = {
        ...baseHeaders,
        Origin: baseUrl,
        Referer: baseUrl + "/",
        Cookie: cookie
      }

      const verifyRes = await axios.post(
        `${baseUrl}/action/userverify`,
        `url=${encodeURIComponent(urls)}`,
        {
          headers: {
            ...headers,
            "Content-Type":
              "application/x-www-form-urlencoded"
          }
        }
      )

      const mainForm = new FormData()

      mainForm.append("url", urls)

      mainForm.append(
        "cf-turnstile-response",
        verifyRes.data.token || ""
      )

      const mainRes = await axios.post(
        `${baseUrl}/action`,
        mainForm,
        {
          headers: {
            ...headers,
            ...mainForm.getHeaders()
          }
        }
      )

      const $ = cheerio.load(mainRes.data.html)

      const rawImg =
        $("img").first().attr("src") || ""

      const thumbnail = rawImg.replace(/\\/g, "")

      const infoContainer = $(".grid-item")
        .eq(1)
        .find(".grid-text")

      const trackForm = new FormData()

      trackForm.append(
        "data",
        $('input[name="data"]').val()
      )

      trackForm.append(
        "base",
        $('input[name="base"]').val()
      )

      trackForm.append(
        "token",
        $('input[name="token"]').val()
      )

      const finalRes = await axios.post(
        `${baseUrl}/action/track`,
        trackForm,
        {
          headers: {
            ...headers,
            ...trackForm.getHeaders()
          }
        }
      )

      const $final = cheerio.load(
        finalRes.data.data
      )

      const dl = $final("a.abutton").attr("href")

      return {
        success: true,
        title: infoContainer
          .find("span")
          .text()
          .trim(),

        artist: infoContainer
          .contents()
          .filter(function () {
            return this.nodeType === 3
          })
          .text()
          .trim(),

        thumbnail,

        download_link: dl.startsWith("http")
          ? dl
          : baseUrl + dl
      }

    } catch (error) {
      return {
        success: false,
        message: error.message
      }
    }
  }

  app.get("/download/aplemate", async (req, res) => {
    try {
      const { url } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          message: "Falta el parámetro url"
        })
      }

      const result = await aplemate(url)

      res.status(200).json({
        status: true,
        result
      })

    } catch (e) {
      res.status(500).json({
        status: false,
        message: e.message
      })
    }
  })

}