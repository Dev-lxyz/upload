const { fbDownload } = require("../../lib/fb")

module.exports = function (app) {

  app.get("/download/facebook/v3", async (req, res) => {
    try {

      const { url } = req.query

      if (!url) {
        return res.status(400).json({
          status: false,
          message: "Missing parameter: url"
        })
      }

      const result = await fbDownload(url)

      if (!result?.code || !result?.data) {
        return res.status(500).json({
          status: false,
          message: "Scraper error",
          result
        })
      }

      return res.json({
        status: true,
        result
      })

    } catch (err) {
      return res.status(500).json({
        status: false,
        message: err.message
      })
    }
  })

}