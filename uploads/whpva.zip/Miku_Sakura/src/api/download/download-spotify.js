module.exports = function (app) {
  const axios = require('axios');
  const https = require('https');
  const cheerio = require('cheerio');

  // 🔥 Axios para fabdl
  const fabdlApi = axios.create({
    baseURL: 'https://api.fabdl.com',
    timeout: 8000,
    httpsAgent: new https.Agent({ keepAlive: true }),
    headers: {
      accept: 'application/json',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
  });

  // 🔥 Axios para spotmate (fallback)
  const spotmateApi = axios.create({
    timeout: 10000,
    httpsAgent: new https.Agent({ keepAlive: true })
  });

  class FabdlManager {
    async fetchWithRetry(url, retries = 2) {
      try {
        return await fabdlApi.get(url);
      } catch (err) {
        if (retries > 0) {
          await new Promise(r => setTimeout(r, 800));
          return this.fetchWithRetry(url, retries - 1);
        }
        throw err;
      }
    }

    async spotifydl(url) {
      const info = await this.fetchWithRetry(
        '/spotify/get?url=' + encodeURIComponent(url)
      );

      if (!info.data?.result) {
        throw new Error('fabdl: no result');
      }

      const r = info.data.result;

      const task = await this.fetchWithRetry(
        `/spotify/mp3-convert-task/${r.gid}/${r.id}`
      );

      if (!task.data?.result?.download_url) {
        throw new Error('fabdl: no download_url');
      }

      const durationMs = Number(r.duration_ms);
      if (!durationMs || isNaN(durationMs)) {
        throw new Error('fabdl: invalid duration');
      }

      const minutes = Math.floor(durationMs / 60000);
      const seconds = Math.floor((durationMs % 60000) / 1000);

      return {
        title: r.name,
        artist: Array.isArray(r.artists)
          ? r.artists.map(a => a.name).join(', ')
          : r.artists || 'Desconocido',
        duration: `${minutes}:${seconds.toString().padStart(2, '0')}`,
        thumbnail: r.image,
        download_url: 'https://api.fabdl.com' + task.data.result.download_url,
        source: 'fabdl'
      };
    }
  }

  class SpotmateManager {
    constructor() {
      this._cookie = null;
      this._token = null;
      this._sessionTime = 0;
    }

    async _visit() {
      const response = await spotmateApi.get('https://spotmate.online/', {
        headers: {
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9',
          'accept-encoding': 'gzip, deflate, br',
          'accept-language': 'es-ES,es;q=0.9',
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });

      const setCookieHeader = response.headers['set-cookie'];
      if (setCookieHeader && Array.isArray(setCookieHeader)) {
        this._cookie = setCookieHeader.map((c) => c.split(';')[0]).join('; ');
      }

      const $ = cheerio.load(response.data);
      this._token = $('meta[name="csrf-token"]').attr('content') || '';
      this._sessionTime = Date.now();
    }

    async getSession() {
      if (!this._cookie || !this._token || (Date.now() - this._sessionTime) > 300000) {
        await this._visit();
      }
    }

    async spotifydl(spotifyUrl) {
      await this.getSession();

      const info = await spotmateApi.post(
        'https://spotmate.online/getTrackData',
        { spotify_url: spotifyUrl },
        {
          headers: this._getHeaders(),
          validateStatus: () => true
        }
      );

      if (!info.data?.id) {
        throw new Error('spotmate: invalid info');
      }

      const converted = await spotmateApi.post(
        'https://spotmate.online/convert',
        { urls: spotifyUrl },
        {
          headers: this._getHeaders(),
          validateStatus: () => true
        }
      );

      if (!converted.data?.url && !converted.data?.download_url) {
        throw new Error('spotmate: no download url');
      }

      const durationMs = Number(info.data.duration_ms) || 0;
      const minutes = Math.floor(durationMs / 60000);
      const seconds = Math.floor((durationMs % 60000) / 1000);

      return {
        title: info.data.name || 'Desconocido',
        artist: info.data.artists?.[0]?.name || 'Desconocido',
        duration: `${minutes}:${seconds.toString().padStart(2, '0')}`,
        thumbnail: info.data.album?.images?.[0]?.url || null,
        download_url: converted.data.download_url || converted.data.url,
        source: 'spotmate'
      };
    }

    _getHeaders() {
      return {
        'accept': 'application/json',
        'accept-encoding': 'gzip, deflate, br',
        'accept-language': 'es-ES,es;q=0.9',
        'content-type': 'application/json',
        'cookie': this._cookie || '',
        'origin': 'https://spotmate.online',
        'referer': 'https://spotmate.online/',
        'x-csrf-token': this._token || '',
        'x-requested-with': 'XMLHttpRequest',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      };
    }
  }

  const fabdl = new FabdlManager();
  const spotmate = new SpotmateManager();

  app.get('/download/spotify', async (req, res) => {
    try {
      const { url } = req.query;

      if (!url) {
        return res.json({
          status: false,
          error: "Falta el parámetro 'url'"
        });
      }

      if (!/^https?:\/\/open\.spotify\.com\/track\//i.test(url)) {
        return res.json({
          status: false,
          error: 'URL de Spotify inválida'
        });
      }

      let result;

      // 1️⃣ Intentar con fabdl primero
      try {
        result = await fabdl.spotifydl(url);
      } catch (fabdlErr) {
        // 2️⃣ Si falla, usar spotmate como fallback
        try {
          result = await spotmate.spotifydl(url);
        } catch (spotmateErr) {
          return res.json({
            status: false,
            error: `Ambas APIs fallaron. fabdl: ${fabdlErr.message}, spotmate: ${spotmateErr.message}`
          });
        }
      }

      res.json({
        status: true,
        result
      });

    } catch (error) {
      res.json({
        status: false,
        error: error.message
      });
    }
  });
};