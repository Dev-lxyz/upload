const axios = require("axios")
const crypto = require("crypto")

class SaveTube {
  constructor() {
    this.ky = "C5D58EF67A7584E4A29F6C35BBC4EB12"
    this.m =
      /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/

    this.is = axios.create({
      headers: {
        "content-type": "application/json",
        origin: "https://yt.savetube.me",
        "user-agent":
          "Mozilla/5.0 (Android 15; Mobile; SM-F958)"
      },
      timeout: 20000
    })
  }

  async decrypt(enc) {
    const sr = Buffer.from(enc, "base64")
    const ky = Buffer.from(this.ky, "hex")

    const iv = sr.slice(0, 16)
    const dt = sr.slice(16)

    const dc = crypto.createDecipheriv("aes-128-cbc", ky, iv)

    return JSON.parse(Buffer.concat([dc.update(dt), dc.final()]).toString())
  }

  async getCdn() {
    const r = await this.is.get(
      "https://media.savetube.vip/api/random-cdn"
    )
    return r.data.cdn
  }

  async download(url, type = "audio", quality = "128") {
    const id = url.match(this.m)?.[3]
    if (!id) throw new Error("ID inválido")

    const cdn = await this.getCdn()

    const info = await this.is.post(`https://${cdn}/v2/info`, {
      url: `https://www.youtube.com/watch?v=${id}`
    })

    const dec = await this.decrypt(info.data.data)

    const dl = await this.is.post(`https://${cdn}/download`, {
      id,
      downloadType: type,
      quality,
      key: dec.key
    })

    return {
      title: dec.title,
      duration: dec.duration,
      thumbnail: dec.thumbnail,
      url: dl.data.data.downloadUrl
    }
  }
}

// ⚡ CACHE
const CACHE = new Map()
const TTL = 5 * 60 * 1000

function formatBytes(bytes) {
  if (!bytes) return "Unknown"
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  const sizes = ["B", "KB", "MB", "GB"]
  return (bytes / Math.pow(1024, i)).toFixed(2) + " " + sizes[i]
}

module.exports = function (app) {
  const sv = new SaveTube()

  app.get("/download/savetube", async (req, res) => {
    const start = Date.now()

    try {
      const { url, type, quality } = req.query

      if (!url) {
        return res.json({ status: false, error: "url requerida" })
      }

      const t = type === "video" ? "video" : "audio"
      const q = quality || (t === "audio" ? "128" : "720")

      const key = `${url}_${t}_${q}`

      // ⚡ CACHE HIT
      const cached = CACHE.get(key)
      if (cached && Date.now() - cached.time < TTL) {
        return res.json({
          ...cached.data,
          cache: true,
          ms: Date.now() - start
        })
      }

      // 🚀 descarga
      const data = await sv.download(url, t, q)

      // ⚡ obtener size rápido (HEAD)
      let size = "Unknown"
      try {
        const head = await axios.head(data.url, { timeout: 5000 })
        const bytes = head.headers["content-length"]
        if (bytes) size = formatBytes(Number(bytes))
      } catch {}

      const result = {
        status: true,
        data: {
          type: t,
          quality: t === "audio" ? q + "kbps" : q + "p",
          title: data.title,
          duration: data.duration,
          thumbnail: data.thumbnail,
          size,
          url: data.url
        }
      }

      // ⚡ guardar cache
      CACHE.set(key, {
        data: result,
        time: Date.now()
      })

      res.json({
        ...result,
        cache: false,
        ms: Date.now() - start
      })

    } catch (e) {
      res.json({
        status: false,
        error: e.message,
        ms: Date.now() - start
      })
    }
  })
}