/*const axios = require("axios")
const cheerio = require("cheerio")

module.exports = function(app) {
  async function downloadFB(url) {
    try {
      const { data } = await axios.post(
        "https://savereels.io/api/ajaxSearch",
        new URLSearchParams({
          q: url,
          w: "",
          v: "v2",
          lang: "id"
        }),

        {
          headers: {
            "Content-Type":
              "application/x-www-form-urlencoded; charset=UTF-8",
            "User-Agent":
              "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36",
            "X-Requested-With":
              "XMLHttpRequest"
          },

          timeout: 15000
        }
      )

      if (data.status !== "ok") {

        return {
          status: false,
          message: "Gagal obtener video"
        }

      }

      const $ = cheerio.load(data.data)

      const videos = []

      const thumbnail =
        $(".image-fb img")
          .attr("src") || null

      const title =
        $(".content h3")
          .text()
          .trim() || "Facebook Video"

      $("table.table tbody tr").each((i, el) => {

        const quality =
          $(el)
            .find(".video-quality")
            .text()
            .trim()

        const downloadUrl =
          $(el)
            .find("a.download-link-fb")
            .attr("href")

        if (
          downloadUrl &&
          quality &&
          !quality.includes("kbps")
        ) {

          videos.push({
            quality,
            url: downloadUrl
          })

        }

      })

      return {
        status: true,
        title,
        thumbnail,
        total: videos.length,
        video: videos,
        audio:
          $("#audioUrl").val() || null
      }

    } catch (error) {

      return {
        status: false,
        error: error.message
      }

    }

  }

  app.get("/download/facebook/v4", async (req, res) => {
    try {
      const { url } = req.query
      if (!url) {
        return res.status(400).json({
          status: false,
          message:
            "Falta el parámetro url"
        })
      }

      const result =
        await downloadFB(url)

      return res.json(result)

    } catch (e) {

      return res.status(500).json({
        status: false,
        error: e.message
      })

    }

  })

}*/


const axios = require("axios")
const cheerio = require("cheerio")

module.exports = function(app) {

  async function downloadFB(url) {
    try {

      const { data } = await axios.post(
        "https://savereels.io/api/ajaxSearch",

        new URLSearchParams({
          q: url,
          w: "",
          v: "v2",
          lang: "id"
        }),

        {
          headers: {
            "Content-Type":
              "application/x-www-form-urlencoded; charset=UTF-8",
            "User-Agent":
              "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36",
            "X-Requested-With":
              "XMLHttpRequest"
          },

          timeout: 15000
        }
      )

      if (data.status !== "ok") {

        return {
          status: false,
          message: "Gagal obtener video"
        }

      }

      const $ = cheerio.load(data.data)

      const videos = []

      const thumbnail =
        $(".image-fb img")
          .attr("src") || null

      const title =
        $(".content h3")
          .text()
          .trim() || "Facebook Video"

      $("table.table tbody tr").each((i, el) => {

        const quality =
          $(el)
            .find(".video-quality")
            .text()
            .trim()

        const downloadUrl =
          $(el)
            .find("a.download-link-fb")
            .attr("href")

        if (
          downloadUrl &&
          quality &&
          !quality.includes("kbps")
        ) {

          videos.push({
            quality,
            url: downloadUrl
          })

        }

      })

      let info = {
        author: "--",
        views: "--",
        reactions: "--",
        description: "Sin descripción",
        date: "Sin fecha",
        canonicalUrl: url,
        thumbnail
      }

      try {

        const { data: html } = await axios.get(url, {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
          },
          timeout: 15000
        })

        const $$ = cheerio.load(html)

        const getMeta = (name, attr = "content") =>
          $$(`meta[property="${name}"]`).attr(attr) ||
          $$(`meta[name="${name}"]`).attr(attr) ||
          null

        const fullTitle =
          getMeta("og:title") ||
          title

        const desc =
          getMeta("og:description") ||
          "Sin descripción"

        const canonicalUrl =
          getMeta("og:url") ||
          url

        const thumb =
          getMeta("og:image") ||
          thumbnail

        const match =
          fullTitle.match(
            /([\d.,]+)\s*mil\s*reproducciones.*?([\d.,]+)\s*mil\s*reacciones\s*\|\s*(.+)\s*\|\s*(.+)$/i
          )

        const views =
          match
            ? match[1] + " mil"
            : "--"

        const reactions =
          match
            ? match[2] + " mil"
            : "--"

        const author =
          match
            ? match[4].trim()
            : "--"

        let date = "Sin fecha"

        if (canonicalUrl !== url) {

          try {

            const { data: html2 } =
              await axios.get(canonicalUrl, {
                headers: {
                  "User-Agent":
                    "Mozilla/5.0"
                },
                timeout: 15000
              })

            const $2 =
              cheerio.load(html2)

            date =
              $2('meta[property="article:published_time"]')
                .attr("content") ||

              $2('meta[property="og:updated_time"]')
                .attr("content") ||

              "Sin fecha"

          } catch {}

        }

        info = {
          author,
          views,
          reactions,
          description: desc,
          date,
          canonicalUrl,
          thumbnail: thumb || thumbnail
        }

      } catch {}

      return {
        status: true,
        title,
        thumbnail: info.thumbnail,
        total: videos.length,

        info: {
          author: info.author,
          views: info.views,
          reactions: info.reactions,
          date: info.date,
          description: info.description,
          url: info.canonicalUrl
        },

        video: videos,

        audio:
          $("#audioUrl").val() || null
      }

    } catch (error) {

      return {
        status: false,
        error: error.message
      }

    }

  }

  app.get("/download/facebook/v4", async (req, res) => {
    try {
      const { url } = req.query

      if (!url) {

        return res.status(400).json({
          status: false,
          message:
            "Falta el parámetro url"
        })

      }

      const result =
        await downloadFB(url)

      return res.json(result)

    } catch (e) {

      return res.status(500).json({
        status: false,
        error: e.message
      })

    }

  })

}