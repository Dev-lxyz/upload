
document.addEventListener('DOMContentLoaded', () => {

  document.body.innerHTML = `
    <div id="app">
      <canvas id="bg"></canvas>

      <header>
        <span class="logo">❀ MIKU SAKURA</span>
        <span class="tag">REST API</span>
        <nav class="nav-links">
          <a href="/docs" class="btn-docs">📄 DOCS</a>
        </nav>
      </header>

      <div class="banner-wrap">
        <img class="banner-img" src="https://i.pinimg.com/originals/f1/7c/be/f17cbe559b0eb996bbc43f876ad0ea6f.jpg" alt="banner" />
        <div class="banner-overlay">
          <h1>API<br><em>STATUS</em></h1>
          <p class="sub">Live metrics · Real-time</p>
        </div>
      </div>

      <main>
        <div class="grid">
          <div class="card wide" id="c-uptime">
            <span class="label">⏱ UPTIME</span>
            <div class="uptime-segments">
              <div class="seg"><span class="seg-val" id="up-d">0</span><span class="seg-u">D</span></div>
              <div class="seg-sep">:</div>
              <div class="seg"><span class="seg-val" id="up-h">00</span><span class="seg-u">H</span></div>
              <div class="seg-sep">:</div>
              <div class="seg"><span class="seg-val" id="up-m">00</span><span class="seg-u">M</span></div>
              <div class="seg-sep">:</div>
              <div class="seg"><span class="seg-val" id="up-s">00</span><span class="seg-u">S</span></div>
            </div>
          </div>

          <div class="card" id="c-creator">
            <span class="label">👤 CREATOR</span>
            <span class="value" id="v-creator">—</span>
          </div>

          <div class="card" id="c-latency">
            <span class="label">⚡ LATENCY</span>
            <div class="latency-wrap">
              <span class="value lat-val" id="v-latency">—</span>
              <span class="unit">ms</span>
            </div>
            <div class="lat-bar-bg"><div class="lat-bar" id="lat-bar"></div></div>
          </div>

          <div class="card wide" id="c-requests">
            <span class="label">📡 TOTAL REQUESTS</span>
            <span class="value big" id="v-requests">—</span>
          </div>

          <div class="card" id="c-routers">
            <span class="label">🔀 ROUTERS</span>
            <span class="value" id="v-routers">—</span>
          </div>

          <div class="card" id="c-endpoints">
            <span class="label">🔗 ENDPOINTS</span>
            <span class="value" id="v-endpoints">—</span>
          </div>

          <div class="card" id="c-processes">
            <span class="label">⚙️ PROCESSES</span>
            <span class="value" id="v-processes">—</span>
          </div>

          <div class="card docs-card" onclick="location.href='/docs'">
            <span class="label">📄 DOCUMENTATION</span>
            <span class="value docs-val">View Docs →</span>
            <span class="docs-hint">Click to open /docs</span>
          </div>
        </div>

        <div class="status-bar">
          <span class="dot" id="dot"></span>
          <span id="status-text">Connecting...</span>
          <span class="clock" id="live-clock"></span>
        </div>
      </main>

      <footer>© Powered by <em>I'm shadow</em></footer>
    </div>
  `

  const style = document.createElement('style')
  style.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Mono:ital,wght@0,300;0,400;1,300&display=swap');

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --bg: #05050a;
      --line: rgba(255,255,255,.07);
      --accent: #c084fc;
      --accent2: #67e8f9;
      --green: #4ade80;
      --text: #e2e2f0;
      --muted: #5a5a7a;
      --card: rgba(255,255,255,.03);
      --card-border: rgba(255,255,255,.09);
    }

    html, body { height: 100%; background: var(--bg); color: var(--text); font-family: 'DM Mono', monospace; overflow-x: hidden; }

    #bg { position: fixed; inset: 0; z-index: 0; pointer-events: none; opacity: .35; }

    #app { position: relative; z-index: 1; min-height: 100vh; display: flex; flex-direction: column; }

    /* ── HEADER ── */
    header {
      display: flex; align-items: center; gap: 12px;
      padding: 18px 40px;
      border-bottom: 1px solid var(--line);
      backdrop-filter: blur(8px);
      position: sticky; top: 0; z-index: 99;
      background: rgba(5,5,10,.7);
    }
    .logo { font-family: 'Bebas Neue', cursive; font-size: 1.6rem; letter-spacing: .15em; color: var(--accent); }
    .tag {
      font-size: .6rem; letter-spacing: .3em;
      color: var(--muted); border: 1px solid var(--muted);
      padding: 2px 8px; border-radius: 4px;
    }
    .nav-links { margin-left: auto; }
    .btn-docs {
      font-family: 'DM Mono', monospace;
      font-size: .65rem; letter-spacing: .2em;
      color: var(--accent2); border: 1px solid var(--accent2);
      padding: 6px 16px; border-radius: 6px;
      text-decoration: none;
      transition: background .2s, color .2s;
    }
    .btn-docs:hover { background: var(--accent2); color: #05050a; }

    /* ── BANNER ── */
    .banner-wrap {
      position: relative; width: 100%; height: 320px; overflow: hidden;
    }
    .banner-img {
      width: 100%; height: 100%; object-fit: cover; object-position: center top;
      filter: brightness(.55) saturate(1.2);
      transition: transform 8s ease;
    }
    .banner-wrap:hover .banner-img { transform: scale(1.04); }
    .banner-overlay {
      position: absolute; inset: 0;
      display: flex; flex-direction: column; justify-content: flex-end;
      padding: 36px 44px;
      background: linear-gradient(to top, rgba(5,5,10,.92) 0%, rgba(5,5,10,.1) 60%, transparent 100%);
    }
    .banner-overlay h1 {
      font-family: 'Bebas Neue', cursive;
      font-size: clamp(3.5rem, 10vw, 7rem);
      line-height: .88; letter-spacing: .02em; color: var(--text);
    }
    .banner-overlay h1 em { color: var(--accent); font-style: normal; }
    .sub { font-size: .68rem; letter-spacing: .3em; color: var(--muted); margin-top: 8px; }

    /* ── MAIN ── */
    main { flex: 1; padding: 36px 40px 28px; max-width: 960px; margin: 0 auto; width: 100%; }

    /* ── GRID ── */
    .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 28px; }

    .card {
      background: var(--card);
      border: 1px solid var(--card-border);
      border-radius: 14px;
      padding: 20px 18px 16px;
      display: flex; flex-direction: column; gap: 8px;
      position: relative; overflow: hidden;
      transition: border-color .25s, transform .2s, box-shadow .25s;
      cursor: default;
    }
    .card::after {
      content: ''; position: absolute; inset: 0;
      background: linear-gradient(135deg, rgba(192,132,252,.05) 0%, transparent 55%);
      pointer-events: none;
    }
    .card:hover {
      border-color: rgba(192,132,252,.35);
      transform: translateY(-3px);
      box-shadow: 0 8px 32px rgba(192,132,252,.08);
    }
    .card.wide { grid-column: span 2; }

    .label { font-size: .57rem; letter-spacing: .28em; color: var(--muted); text-transform: uppercase; }
    .value { font-size: 1.5rem; font-weight: 300; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .value.big { font-size: 2.6rem; color: var(--accent); font-family: 'Bebas Neue', cursive; letter-spacing: .05em; }
    .unit { font-size: .62rem; color: var(--muted); margin-top: -4px; }

    /* ── UPTIME SEGMENTS ── */
    .uptime-segments {
      display: flex; align-items: flex-end; gap: 4px;
    }
    .seg { display: flex; align-items: baseline; gap: 3px; }
    .seg-val {
      font-family: 'Bebas Neue', cursive;
      font-size: 2.2rem; color: var(--accent2);
      line-height: 1;
      min-width: 2ch; text-align: center;
      transition: color .3s;
    }
    .seg-u { font-size: .6rem; letter-spacing: .2em; color: var(--muted); margin-bottom: 4px; }
    .seg-sep { font-size: 1.6rem; color: var(--muted); margin-bottom: 6px; line-height: 1; }

    /* ── LATENCY BAR ── */
    .latency-wrap { display: flex; align-items: baseline; gap: 6px; }
    .lat-val { color: var(--green); transition: color .3s; }
    .lat-bar-bg {
      height: 3px; background: rgba(255,255,255,.08);
      border-radius: 2px; overflow: hidden; margin-top: 4px;
    }
    .lat-bar {
      height: 100%; width: 0%; background: var(--green);
      border-radius: 2px;
      transition: width .5s ease, background .5s;
    }

    /* ── DOCS CARD ── */
    .docs-card { cursor: pointer; border-color: rgba(103,232,249,.15); }
    .docs-card:hover { border-color: var(--accent2); box-shadow: 0 8px 32px rgba(103,232,249,.1); }
    .docs-val { color: var(--accent2); font-size: 1.1rem; letter-spacing: .05em; }
    .docs-hint { font-size: .58rem; color: var(--muted); letter-spacing: .15em; margin-top: -4px; }

    /* ── STATUS BAR ── */
    .status-bar {
      display: flex; align-items: center; gap: 10px;
      font-size: .62rem; letter-spacing: .15em; color: var(--muted);
    }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--muted); transition: background .4s; flex-shrink: 0; }
    .dot.ok { background: var(--green); box-shadow: 0 0 8px var(--green); animation: pulse 2s infinite; }
    .dot.err { background: #f87171; box-shadow: 0 0 8px #f87171; }
    .clock { margin-left: auto; font-size: .6rem; color: var(--muted); font-variant-numeric: tabular-nums; }

    @keyframes pulse { 0%,100%{opacity:1}50%{opacity:.35} }

    /* ── FOOTER ── */
    footer { text-align: center; padding: 18px; font-size: .58rem; letter-spacing: .2em; color: var(--muted); border-top: 1px solid var(--line); }
    footer em { color: var(--accent2); font-style: normal; }

    /* ── ANIMATE IN ── */
    .card { animation: fadeUp .5s ease both; }
    .card:nth-child(1){animation-delay:.04s} .card:nth-child(2){animation-delay:.08s}
    .card:nth-child(3){animation-delay:.12s} .card:nth-child(4){animation-delay:.16s}
    .card:nth-child(5){animation-delay:.20s} .card:nth-child(6){animation-delay:.24s}
    .card:nth-child(7){animation-delay:.28s} .card:nth-child(8){animation-delay:.32s}

    @keyframes fadeUp { from{opacity:0;transform:translateY(18px)} to{opacity:1;transform:translateY(0)} }

    @media (max-width: 640px) {
      header { padding: 14px 18px; }
      main { padding: 24px 18px; }
      .banner-wrap { height: 220px; }
      .banner-overlay { padding: 24px 20px; }
      .grid { grid-template-columns: repeat(2, 1fr); }
      .card.wide { grid-column: span 2; }
    }
  `
  document.head.appendChild(style)

  // ── CANVAS BACKGROUND ────────────────────────────────────────
  const canvas = document.getElementById('bg')
  const ctx = canvas.getContext('2d')
  let W, H, particles = []

  function resize() { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight }

  function initParticles() {
    particles = Array.from({ length: 60 }, () => ({
      x: Math.random() * W, y: Math.random() * H,
      r: Math.random() * 1.4 + .3,
      vx: (Math.random() - .5) * .28,
      vy: (Math.random() - .5) * .28,
      a: Math.random() * .8 + .2
    }))
  }

  function drawBg() {
    ctx.clearRect(0, 0, W, H)
    ctx.strokeStyle = 'rgba(192,132,252,.035)'
    ctx.lineWidth = 1
    const gs = 64
    for (let x = 0; x < W; x += gs) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke() }
    for (let y = 0; y < H; y += gs) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke() }
    particles.forEach(p => {
      p.x += p.vx; p.y += p.vy
      if (p.x < 0) p.x = W; if (p.x > W) p.x = 0
      if (p.y < 0) p.y = H; if (p.y > H) p.y = 0
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(103,232,249,${p.a * .55})`
      ctx.fill()
    })
    requestAnimationFrame(drawBg)
  }

  resize(); initParticles(); drawBg()
  window.addEventListener('resize', () => { resize(); initParticles() })

  let apiStartMs = null
  let baseUptimeSec = 0

  function set(id, val) { const e = document.getElementById(id); if (e) e.textContent = val }

  function renderUptime() {
    if (apiStartMs === null) return
    const elapsed = Math.floor((Date.now() - apiStartMs) / 1000)
    let total = baseUptimeSec + elapsed

    const d = Math.floor(total / 86400); total %= 86400
    const h = Math.floor(total / 3600);  total %= 3600
    const m = Math.floor(total / 60)
    const s = total % 60

    set('up-d', d)
    set('up-h', String(h).padStart(2, '0'))
    set('up-m', String(m).padStart(2, '0'))
    set('up-s', String(s).padStart(2, '0'))

    const sv = document.getElementById('up-s')
    if (sv) { sv.style.color = '#fff'; setTimeout(() => sv.style.color = '', 120) }
  }

  function renderClock() {
    set('live-clock', new Date().toLocaleTimeString())
  }

  function latencyColor(ms) {
    if (ms < 80)  return '#4ade80'
    if (ms < 200) return '#facc15'
    return '#f87171'
  }

  function renderLatency(ms) {
    const el = document.getElementById('v-latency')
    const bar = document.getElementById('lat-bar')
    if (!el || !bar) return
    el.textContent = ms
    const color = latencyColor(ms)
    el.style.color = color
    const pct = Math.min((ms / 500) * 100, 100)
    bar.style.width = pct + '%'
    bar.style.background = color
  }

  async function fetchStatus() {
    const dot = document.getElementById('dot')
    const statusText = document.getElementById('status-text')

    try {
      const t0 = Date.now()
      const res = await fetch('/status-page')
      const clientLatency = Date.now() - t0
      if (!res.ok) throw new Error('HTTP ' + res.status)
      const d = await res.json()

      const uptimeStr = d.uptime || '0D, 0H, 0M, 0S'
      const [dd=0,hh=0,mm=0,ss=0] = uptimeStr.match(/\d+/g).map(Number)
      baseUptimeSec = dd*86400 + hh*3600 + mm*60 + ss
      apiStartMs = Date.now()
      const latMs = d.api_latency_ms ?? clientLatency
      renderLatency(latMs)

      set('v-creator',   d.creator                         || '—')
      set('v-requests',  d.total_requests                  ?? '—')
      set('v-routers',   d.routes_loaded                   ?? '—')
      set('v-endpoints', d.endpoints_hit ?? d.routes_loaded ?? '—')
      set('v-processes', d.system?.running_processes        ?? '—')

      dot.className = 'dot ok'
      statusText.textContent = 'Online'
    } catch (e) {
      dot.className = 'dot err'
      statusText.textContent = 'Error: ' + e.message
    }
  }

  setInterval(() => {
    renderUptime()
    renderClock()
  }, 1000)

  fetchStatus()
  setInterval(fetchStatus, 5_000)
})
