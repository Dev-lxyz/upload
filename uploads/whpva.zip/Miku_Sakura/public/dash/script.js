/* ═══════════════════════════════════════════════════════════════
   Nexus API Dashboard · dash/script.js
   ═══════════════════════════════════════════════════════════════ */

'use strict';

// ─── Globals ────────────────────────────────────────────────────
const BASE = window.location.origin;
const $    = id => document.getElementById(id);

let DATA           = null;
let SETTINGS       = null;
let lastResponse   = {};
let uptimeStart    = Date.now();
let uptimeInterval = null;

// ─── Color / Icon Maps ───────────────────────────────────────────
const CAT_COLORS = {
  search:      '#06b6d4', random:   '#7c3aed', canvas:  '#f97316',
  tools:       '#06b6d4', anime:    '#ec4899', nsfw:    '#f43f5e',
  stalking:    '#a855f7', download: '#10b981', reaction:'#ec4899',
  play:        '#f97316', api:      '#06b6d4', ai:      '#7c3aed',
  sticker:     '#ec4899','api status':'#06b6d4',
};
const CAT_ICONS = {
  search:      'fa-magnifying-glass', random:   'fa-shuffle',    canvas:  'fa-palette',
  tools:       'fa-screwdriver-wrench',anime:   'fa-film',       nsfw:    'fa-lock',
  stalking:    'fa-user-secret',      download: 'fa-download',   reaction:'fa-face-smile',
  play:        'fa-play',             api:      'fa-code',       ai:      'fa-brain',
  sticker:     'fa-image',           'api status':'fa-server',
};
const catColor = n => CAT_COLORS[n.toLowerCase()] || '#7c3aed';
const catIcon  = n => CAT_ICONS[n.toLowerCase()]  || 'fa-folder';

// ─── Bootstrap ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);

  Promise.all([
    fetch('/src/endpoint.json').then(r => r.json()),
    fetch('/src/settings.json').then(r => r.json()),
  ])
    .then(([epData, stData]) => {
      DATA     = epData;
      SETTINGS = stData;

      const first = SETTINGS.name.split(' ')[0];
      $('logo-name').textContent   = first;
      $('logo-mark').textContent   = first[0] || '⚡';
      $('status-text').textContent = SETTINGS.header.status;

      renderAll();
    })
    .catch(err => console.error('[Nexus] Boot error:', err));
});

// ─── Stats ──────────────────────────────────────────────────────
function calcStats() {
  if (!DATA) return { cats: 0, eps: 0 };
  let eps = 0;
  DATA.categories.forEach(c => (eps += c.items.length));
  return { cats: DATA.categories.length, eps };
}

// ─── Uptime ─────────────────────────────────────────────────────
function startUptime() {
  uptimeStart = Date.now();
  if (uptimeInterval) clearInterval(uptimeInterval);
  uptimeInterval = setInterval(tickUptime, 1000);
  tickUptime();
}

function tickUptime() {
  const el = $('uptime-val');
  if (!el) return;
  const s   = Math.floor((Date.now() - uptimeStart) / 1000);
  const d   = Math.floor(s / 86400);
  const h   = Math.floor((s % 86400) / 3600);
  const m   = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  el.textContent = `${d}d ${pad(h)}h ${pad(m)}m ${pad(sec)}s`;
}

const pad = n => String(n).padStart(2, '0');

// ─── Latency ─────────────────────────────────────────────────────
async function measureLatency() {
  const el = $('latency-val');
  if (!el) return;
  try {
    const t0 = performance.now();
    await fetch('/src/settings.json', { cache: 'no-store' });
    const ms = Math.round(performance.now() - t0);
    el.textContent = ms + ' ms';
    el.style.color = ms < 100 ? 'var(--ok)' : ms < 300 ? 'var(--warn)' : 'var(--acc3)';
  } catch {
    el.textContent = 'error';
    el.style.color = 'var(--acc3)';
  }
}

// ─── SPA Navigation ─────────────────────────────────────────────
// Home view and category view coexist in the DOM, toggled with display.

window.goHome = function () {
  const hv = $('home-view');
  const cv = $('cats-view');
  if (hv) hv.style.display = '';
  if (cv) cv.style.display = 'none';
  document.querySelectorAll('.cat-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('#sb-cats .sb-item').forEach(el => el.classList.remove('active'));
  $('nav-home')?.classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

window.selectCategory = function (idx) {
  const hv = $('home-view');
  const cv = $('cats-view');
  if (hv) hv.style.display = 'none';
  if (cv) cv.style.display = '';
  document.querySelectorAll('.cat-section').forEach(s => s.classList.remove('active'));
  const sec = $('cat-' + idx);
  if (sec) {
    sec.classList.add('active');
    setTimeout(() => sec.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
  }
  document.querySelectorAll('#sb-cats .sb-item').forEach((el, i) =>
    el.classList.toggle('active', i === idx));
  $('nav-home')?.classList.remove('active');
};

// ─── Theme / Sidebar ────────────────────────────────────────────
window.toggleTheme = function () {
  const html = document.documentElement;
  const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  toast(next === 'dark' ? '🌙 Dark mode' : '☀️ Light mode');
};

window.toggleSidebar = function () {
  $('sidebar').classList.toggle('open');
};

// ─── Toast ──────────────────────────────────────────────────────
window.toast = function (msg) {
  const el = $('toast');
  $('toast-msg').textContent = msg;
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 2800);
};

// ─── JSON Syntax ────────────────────────────────────────────────
function highlight(json) {
  json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return json.replace(
    /("(?:\\u[\da-fA-F]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(?:true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
    m => {
      if (/^"/.test(m)) return '<span class="' + (/:$/.test(m) ? 'jk' : 'js') + '">' + m + '</span>';
      if (/true|false/.test(m)) return '<span class="jb">' + m + '</span>';
      if (/null/.test(m))       return '<span class="jnull">' + m + '</span>';
      return '<span class="jn">' + m + '</span>';
    }
  );
}

// ─── Render All (once) ───────────────────────────────────────────
function renderAll() {
  if (!DATA || !SETTINGS) return;
  const { cats, eps } = calcStats();
  const content = $('content');

  // Intro divider
  let html = `
    <div class="intro-rule">
      <span class="intro-line"></span>
      <span class="intro-label"><i class="fas fa-bolt"></i> Nexus API</span>
      <span class="intro-line"></span>
    </div>
  `;

  // ══ HOME VIEW ══
  html += `<div id="home-view">`;

  html += `
    <section class="hero">
      <img class="hero-img" src="${SETTINGS.header.imageSrc}" alt="${SETTINGS.name}">
      <div class="hero-eyebrow">${SETTINGS.header.status}</div>
      <h1 class="hero-title">${SETTINGS.name}</h1>
      <p class="hero-sub">${SETTINGS.description}</p>
    </section>

    <div class="stats-row">
      <div class="stat-card">
        <div class="stat-icon g"><i class="fas fa-circle-check"></i></div>
        <div>
          <div class="stat-val">${escHtml(SETTINGS.header.status)}</div>
          <div class="stat-lbl">Estado</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon b"><i class="fas fa-folder"></i></div>
        <div>
          <div class="stat-val">${cats}</div>
          <div class="stat-lbl">Categorías</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon p"><i class="fas fa-code"></i></div>
        <div>
          <div class="stat-val">${eps}</div>
          <div class="stat-lbl">Endpoints</div>
        </div>
      </div>
    </div>

    <div class="meta-row">
      <div class="meta-card">
        <i class="fas fa-rocket" style="color:var(--acc)"></i>
        <div class="meta-title">Version</div>
        <div class="meta-val">${escHtml(SETTINGS.version)}</div>
      </div>
      <div class="meta-card">
        <i class="fas fa-key" style="color:var(--ok)"></i>
        <div class="meta-title">API Key</div>
        <div class="meta-val mono">${escHtml(SETTINGS.apiSettings.key)}</div>
      </div>
      <div class="meta-card">
        <i class="fas fa-gauge-high" style="color:var(--warn)"></i>
        <div class="meta-title">Rate Limit</div>
        <div class="meta-val">${escHtml(String(SETTINGS.apiSettings.limit))}</div>
      </div>
      <div class="meta-card">
        <i class="fas fa-clock" style="color:var(--acc2)"></i>
        <div class="meta-title">Uptime</div>
        <div class="meta-val mono" id="uptime-val">0d 00h 00m 00s</div>
      </div>
      <div class="meta-card">
        <i class="fas fa-bolt" style="color:var(--acc3)"></i>
        <div class="meta-title">Latency</div>
        <div class="meta-val mono" id="latency-val">—</div>
      </div>
    </div>
  `;

  // Creator
  const owner = (SETTINGS.colaborador || []).find(c => c.type?.includes('Owner'));
  if (owner) {
    html += `
      <div class="section-title">Creator</div>
      <div class="creator-wrap">
        <img class="creator-img" src="${escHtml(owner.icon)}" alt="${escHtml(owner.name)}">
        <div>
          <div class="creator-name">${escHtml(owner.name)}</div>
          <div class="creator-role">${escHtml(owner.type)}</div>
        </div>
        <a class="creator-link" href="${escHtml(owner.redes)}" target="_blank" rel="noopener">
          <i class="fab fa-github"></i> GitHub
        </a>
      </div>
    `;
  }

  // Collabs
  const collabs = (SETTINGS.colaborador || []).filter(c => !c.type?.includes('Owner'));
  if (collabs.length) {
    html += `<div class="section-title">Colaboradores</div><div class="collabs-grid">`;
    collabs.forEach(c => {
      html += `
        <div class="collab-card">
          <img class="collab-img" src="${escHtml(c.icon)}" alt="${escHtml(c.name)}">
          <div class="collab-name">${escHtml(c.name)}</div>
          <div class="collab-role">${escHtml(c.type)}</div>
          <a class="collab-link" href="${escHtml(c.redes)}" target="_blank" rel="noopener">
            <i class="fab fa-github"></i> Perfil
          </a>
        </div>
      `;
    });
    html += `</div>`;
  }

  // Category cards
  html += `<div class="section-title">Categorías</div><div class="cats-grid">`;
  DATA.categories.forEach((cat, idx) => {
    const color  = catColor(cat.name);
    const icon   = catIcon(cat.name);
    const active = cat.status !== false;
    html += `
      <div class="cat-card ${active ? '' : 'inactive'}" style="--cat-color:${color}"
           onclick="${active ? 'selectCategory(' + idx + ')' : ''}">
        <div class="cat-ico"><i class="fas ${icon}"></i></div>
        <div class="cat-name">${escHtml(cat.name)}</div>
        <div class="cat-count">${cat.items.length} endpoints</div>
        <div class="cat-status-badge ${active ? 'on' : 'off'}">${active ? 'Active' : 'Offline'}</div>
      </div>
    `;
  });
  html += `</div>`;

  html += `</div>`; // #home-view end

  // ══ CATS VIEW ══
  html += `<div id="cats-view" style="display:none">`;
  DATA.categories.forEach((cat, cidx) => {
    html += buildCategorySection(cat, cidx);
  });
  html += `</div>`;

  content.innerHTML = html;

  renderSidebar();

  // Attach form submit handlers
  DATA.categories.forEach((cat, cidx) => {
    cat.items.forEach((ep, eidx) => {
      const form = $('form-' + cidx + '-' + eidx);
      if (form) form.addEventListener('submit', e => executeEndpoint(e, cidx, eidx));
    });
  });

  startUptime();
  measureLatency();
  $('nav-home')?.classList.add('active');
}

// ─── Sidebar ────────────────────────────────────────────────────
function renderSidebar() {
  if (!DATA || !SETTINGS) return;

  let cHtml = '<div class="sb-section-label" style="margin-top:0">Categorías</div>';
  DATA.categories.forEach((cat, idx) => {
    const off = cat.status === false;
    cHtml += `
      <button class="sb-item${off ? ' sb-off' : ''}"
              ${off ? 'disabled' : 'onclick="selectCategory(' + idx + ')"'}>
        <i class="fas ${catIcon(cat.name)}"></i>
        ${escHtml(cat.name)}
        <span class="sb-badge">${cat.items.length}</span>
      </button>
    `;
  });
  $('sb-cats').innerHTML = cHtml;

  let lHtml = '<div class="sb-section-label">Support</div>';
  (SETTINGS.links || []).forEach(l => {
    lHtml += `<a class="sb-item" href="${escHtml(l.url)}" target="_blank" rel="noopener">
      <i class="fas fa-arrow-up-right-from-square"></i>${escHtml(l.name)}
    </a>`;
  });
  $('sb-links').innerHTML = lHtml;
}

// ─── Build: Category Section ─────────────────────────────────────
function buildCategorySection(cat, cidx) {
  const icon = catIcon(cat.name);
  let html = `
    <div class="cat-section" id="cat-${cidx}">
      <div class="sec-head">
        <div class="sec-icon"><i class="fas ${icon}"></i></div>
        <div>
          <div class="sec-name">${escHtml(cat.name)}</div>
          <div class="sec-sub">${cat.items.length} endpoints disponibles</div>
        </div>
        <button class="back-btn" onclick="goHome()">
          <i class="fas fa-arrow-left"></i> Home
        </button>
      </div>
      <div class="search-bar">
        <i class="fas fa-magnifying-glass"></i>
        <input class="ep-search" data-cat="${cidx}" type="text"
               placeholder="Buscar endpoint…" oninput="filterEps(${cidx})">
      </div>
      <div class="eps-list" id="eps-${cidx}">
  `;
  cat.items.forEach((ep, eidx) => {
    html += buildEndpoint(ep, cidx, eidx);
  });
  html += `</div></div>`;
  return html;
}

// ─── Build: Endpoint ────────────────────────────────────────────
function buildEndpoint(ep, cidx, eidx) {
  const method   = (ep.method || 'GET').toLowerCase();
  const statusOn = ep.status !== false;
  const desc     = ep.desc || 'Sin descripción disponible.';
  const key      = cidx + '-' + eidx;

  let body = '';
  if (statusOn) {
    body = `
      <div class="ep-body" id="body-${key}">
        <div class="ep-desc">${escHtml(desc)}</div>
        <div class="url-row" id="url-${key}">
          <span class="url-text">${escHtml(BASE + ep.path)}</span>
          <button type="button" class="url-copy" onclick="copyUrl('${key}')">
            <i class="fas fa-copy"></i>
          </button>
        </div>
        <form class="ep-form" id="form-${key}">
          ${buildFormFields(ep.params)}
          <button type="submit" class="btn-run">
            <i class="fas fa-play"></i> ᥱ᥊ᥱᥴᥙ𝗍ᥱ
          </button>
        </form>
        <div class="resp-panel" id="resp-${key}">
          <div class="resp-head">
            <div class="resp-status">
              <div class="resp-dot" id="rdot-${key}"></div>
              <span id="rtxt-${key}">—</span>
            </div>
            <div class="resp-actions">
              <button type="button" class="btn-sm" onclick="copyResp('${key}')">
                <i class="fas fa-copy"></i> Copy
              </button>
              <button type="button" class="btn-sm" onclick="dlResp('${key}')">
                <i class="fas fa-download"></i> DL
              </button>
              <button type="button" class="btn-sm" onclick="clearResp('${key}')">
                <i class="fas fa-xmark"></i>
              </button>
            </div>
          </div>
          <div class="resp-content" id="rc-${key}"></div>
        </div>
      </div>
    `;
  }

  return `
    <div class="ep${statusOn ? '' : ' disabled'}" id="ep-${key}">
      <div class="ep-head" ${statusOn ? 'onclick="toggleEp(\'' + key + '\')"' : ''}>
        <div class="ep-method ${method}">${method.toUpperCase()}</div>
        <div class="ep-info">
          <div class="ep-path">${escHtml(ep.path)}</div>
          <div class="ep-name">${escHtml(ep.name || '')}</div>
        </div>
        <div class="ep-badge ${statusOn ? 'on' : 'off'}">${statusOn ? 'active' : 'offline'}</div>
        ${statusOn ? `<button class="ep-chevron" id="chev-${key}"
          onclick="event.stopPropagation();toggleEp('${key}')">
          <i class="fas fa-chevron-down"></i></button>` : ''}
      </div>
      ${body}
    </div>
  `;
}

// ─── Build: Form Fields ──────────────────────────────────────────
function buildFormFields(params) {
  if (!params) {
    return '<p class="no-params">Sin parámetros requeridos.</p>';
  }

  let html = '';

  if (Array.isArray(params)) {
    params.forEach(sel => {
      if (!sel.name || !sel.options) return;
      html += `
        <div class="f-group">
          <label class="f-label">${escHtml(sel.label || sel.name)}</label>
          <select class="f-select ep-param" data-param="${escHtml(sel.name)}">
            <option value="">— ${escHtml(sel.label || sel.name)} —</option>
            ${sel.options.map(o => `<option value="${escHtml(o.value)}">${escHtml(o.label)}</option>`).join('')}
          </select>
        </div>
      `;
    });
  } else {
    Object.entries(params).forEach(([key, val]) => {
      if (val && typeof val === 'object' && val.options) {
        html += `
          <div class="f-group">
            <label class="f-label">${escHtml(val.label || key)}</label>
            <select class="f-select ep-param" data-param="${escHtml(val.name || key)}">
              <option value="">— ${escHtml(val.label || key)} —</option>
              ${val.options.map(o => `<option value="${escHtml(o.value)}">${escHtml(o.label)}</option>`).join('')}
            </select>
          </div>
        `;
      } else {
        html += `
          <div class="f-group">
            <label class="f-label">${escHtml(key)}</label>
            <input class="f-input ep-param" type="text"
                   data-param="${escHtml(key)}" placeholder="${escHtml(String(val || ''))}">
          </div>
        `;
      }
    });
  }

  return html || '<p class="no-params">Sin parámetros.</p>';
}

// ─── Utils ──────────────────────────────────────────────────────
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ─── Toggle Endpoint ────────────────────────────────────────────
window.toggleEp = function (key) {
  $('body-' + key)?.classList.toggle('open');
  $('chev-' + key)?.classList.toggle('open');
};

// ─── Filter ─────────────────────────────────────────────────────
window.filterEps = function (cidx) {
  const q = document.querySelector('.ep-search[data-cat="' + cidx + '"]')?.value.toLowerCase() || '';
  document.querySelectorAll('#eps-' + cidx + ' .ep').forEach(el => {
    const path = el.querySelector('.ep-path')?.textContent.toLowerCase() || '';
    const name = el.querySelector('.ep-name')?.textContent.toLowerCase() || '';
    el.classList.toggle('hidden', q !== '' && !path.includes(q) && !name.includes(q));
  });
};

// ─── Build URL ──────────────────────────────────────────────────
function buildUrl(cidx, eidx) {
  const ep     = DATA.categories[cidx].items[eidx];
  const base   = BASE + ep.path.split('?')[0];
  const params = new URLSearchParams();
  document.querySelectorAll('#form-' + cidx + '-' + eidx + ' .ep-param').forEach(inp => {
    const v = inp.value.trim();
    if (v) params.append(inp.getAttribute('data-param'), v);
  });
  return params.toString() ? base + '?' + params : base;
}

// ─── Copy URL ───────────────────────────────────────────────────
window.copyUrl = function (key) {
  const [cidx, eidx] = key.split('-').map(Number);
  navigator.clipboard.writeText(buildUrl(cidx, eidx));
  toast('URL copiada ✓');
};

// ─── Execute ────────────────────────────────────────────────────
async function executeEndpoint(e, cidx, eidx) {
  e.preventDefault();

  const key  = cidx + '-' + eidx;
  const btn  = e.target.querySelector('.btn-run');
  const resp = $('resp-' + key);
  const rc   = $('rc-' + key);
  const rdot = $('rdot-' + key);
  const rtxt = $('rtxt-' + key);

  // Loading state
  btn.classList.add('loading');
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Ejecutando…';
  resp.classList.add('open');
  rc.textContent = '';

  const url = buildUrl(cidx, eidx);

  // Update URL display
  const urlText = $('url-' + key)?.querySelector('.url-text');
  if (urlText) urlText.textContent = url;

  const t0 = performance.now();

  try {
    const res = await fetch(url);
    const ms  = Math.round(performance.now() - t0);
    const ct  = res.headers.get('content-type') || '';

    const isOk = res.ok; // 2xx
    rdot.className = 'resp-dot' + (isOk ? '' : ' err');
    rtxt.textContent = 'HTTP ' + res.status + ' · ' + ms + 'ms';

    if (ct.includes('application/json')) {
      // Always parse JSON, even on 4xx/5xx
      const raw  = await res.text();
      let parsed;
      try {
        parsed = JSON.parse(raw);
        lastResponse[key] = parsed;
        rc.innerHTML = highlight(JSON.stringify(parsed, null, 2));
      } catch {
        rc.textContent = raw;
      }

    } else if (ct.includes('text/html')) {
      // Render HTML response inside a sandboxed iframe
      const raw = await res.text();
      const prefix = isOk ? '' : `<div style="margin-bottom:8px;font-size:11px;color:var(--acc3)">⚠ HTTP ${res.status} — HTML response:</div>`;
      rc.innerHTML = prefix + `<iframe
        sandbox="allow-same-origin"
        style="width:100%;min-height:300px;border:none;border-radius:6px;background:#fff"
        srcdoc="${raw.replace(/\\/g, '\\\\').replace(/"/g, '&quot;').replace(/`/g, '\\`')}">
      </iframe>`;

    } else if (ct.includes('image/')) {
      const blob = await res.blob();
      rc.innerHTML = `<img src="${URL.createObjectURL(blob)}" alt="response image">`;

    } else if (ct.includes('video/')) {
      const blob = await res.blob();
      rc.innerHTML = `<video controls style="width:100%"><source src="${URL.createObjectURL(blob)}"></video>`;

    } else if (ct.includes('audio/')) {
      const blob = await res.blob();
      rc.innerHTML = `<audio controls><source src="${URL.createObjectURL(blob)}"></audio>`;

    } else {
      rc.textContent = (await res.text()) || '(vacío)';
    }

    toast((isOk ? '✓' : '✗') + ' HTTP ' + res.status + ' · ' + ms + 'ms');

  } catch (err) {
    rdot.className = 'resp-dot err';
    rtxt.textContent = 'Network Error';
    rc.textContent = 'Network Error: ' + err.message;
    toast('Error de red');
  } finally {
    btn.classList.remove('loading');
    btn.innerHTML = '<i class="fas fa-play"></i> ᥱ᥊ᥱᥴᥙ𝗍ᥱ';
  }
}

// ─── Response Actions ────────────────────────────────────────────
window.copyResp = function (key) {
  navigator.clipboard.writeText($('rc-' + key)?.textContent || '');
  toast('Copiado ✓');
};

window.dlResp = function (key) {
  const data = lastResponse[key];
  if (!data) { toast('Sin datos JSON'); return; }
  const a = Object.assign(document.createElement('a'), {
    href:     URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })),
    download: 'response-' + key + '.json',
  });
  a.click();
  toast('Descargado ✓');
};

window.clearResp = function (key) {
  $('resp-' + key)?.classList.remove('open');
  const rc = $('rc-' + key);
  if (rc) rc.innerHTML = '';
  delete lastResponse[key];
};
